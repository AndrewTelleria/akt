--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 9.5.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO andrew;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO andrew;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO andrew;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO andrew;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO andrew;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO andrew;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO andrew;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO andrew;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO andrew;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO andrew;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO andrew;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO andrew;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: blog_blogindexpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.blog_blogindexpage (
    page_ptr_id integer NOT NULL,
    intro text NOT NULL
);


ALTER TABLE public.blog_blogindexpage OWNER TO andrew;

--
-- Name: blog_blogpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.blog_blogpage (
    page_ptr_id integer NOT NULL,
    feature integer NOT NULL,
    date date NOT NULL,
    intro character varying(250) NOT NULL,
    body text NOT NULL,
    author_id integer,
    image_id integer
);


ALTER TABLE public.blog_blogpage OWNER TO andrew;

--
-- Name: blog_blogpagetag; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.blog_blogpagetag (
    id integer NOT NULL,
    content_object_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.blog_blogpagetag OWNER TO andrew;

--
-- Name: blog_blogpagetag_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.blog_blogpagetag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_blogpagetag_id_seq OWNER TO andrew;

--
-- Name: blog_blogpagetag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.blog_blogpagetag_id_seq OWNED BY public.blog_blogpagetag.id;


--
-- Name: blog_blogtagindexpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.blog_blogtagindexpage (
    page_ptr_id integer NOT NULL
);


ALTER TABLE public.blog_blogtagindexpage OWNER TO andrew;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO andrew;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO andrew;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO andrew;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO andrew;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO andrew;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO andrew;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO andrew;

--
-- Name: home_homepage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.home_homepage (
    page_ptr_id integer NOT NULL,
    hero_text character varying(255) NOT NULL,
    hero_title character varying(255) NOT NULL,
    body text NOT NULL,
    promo_title character varying(255),
    promo_text text,
    featured_section_1_title character varying(255),
    featured_section_2_title character varying(255),
    featured_section_1_id integer,
    featured_section_2_id integer,
    promo_image_id integer,
    resume_id integer
);


ALTER TABLE public.home_homepage OWNER TO andrew;

--
-- Name: home_homepageimagegallery; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.home_homepageimagegallery (
    id integer NOT NULL,
    sort_order integer,
    caption character varying(250) NOT NULL,
    logo boolean NOT NULL,
    image_id integer NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.home_homepageimagegallery OWNER TO andrew;

--
-- Name: home_homepageimagegallery_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.home_homepageimagegallery_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_homepageimagegallery_id_seq OWNER TO andrew;

--
-- Name: home_homepageimagegallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.home_homepageimagegallery_id_seq OWNED BY public.home_homepageimagegallery.id;


--
-- Name: home_people; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.home_people (
    id integer NOT NULL,
    first_name character varying(254) NOT NULL,
    last_name character varying(254) NOT NULL,
    job_title character varying(254) NOT NULL,
    about text NOT NULL,
    image_id integer
);


ALTER TABLE public.home_people OWNER TO andrew;

--
-- Name: home_people_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.home_people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_people_id_seq OWNER TO andrew;

--
-- Name: home_people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.home_people_id_seq OWNED BY public.home_people.id;


--
-- Name: home_skills; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.home_skills (
    id integer NOT NULL,
    sort_order integer,
    skill character varying(255),
    percentage integer,
    page_id integer NOT NULL
);


ALTER TABLE public.home_skills OWNER TO andrew;

--
-- Name: home_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.home_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_skills_id_seq OWNER TO andrew;

--
-- Name: home_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.home_skills_id_seq OWNED BY public.home_skills.id;


--
-- Name: home_standardpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.home_standardpage (
    page_ptr_id integer NOT NULL,
    introduction text NOT NULL,
    body text NOT NULL,
    image_id integer
);


ALTER TABLE public.home_standardpage OWNER TO andrew;

--
-- Name: projects_projectindexpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.projects_projectindexpage (
    page_ptr_id integer NOT NULL,
    intro text NOT NULL
);


ALTER TABLE public.projects_projectindexpage OWNER TO andrew;

--
-- Name: projects_projectpage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.projects_projectpage (
    page_ptr_id integer NOT NULL,
    feature integer NOT NULL,
    project_url character varying(250),
    github character varying(250),
    date date NOT NULL,
    intro character varying(250) NOT NULL,
    body text NOT NULL,
    image_id integer
);


ALTER TABLE public.projects_projectpage OWNER TO andrew;

--
-- Name: projects_projectpagegalleryimage; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.projects_projectpagegalleryimage (
    id integer NOT NULL,
    sort_order integer,
    caption character varying(250) NOT NULL,
    image_id integer NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.projects_projectpagegalleryimage OWNER TO andrew;

--
-- Name: projects_projectpagegalleryimage_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.projects_projectpagegalleryimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_projectpagegalleryimage_id_seq OWNER TO andrew;

--
-- Name: projects_projectpagegalleryimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.projects_projectpagegalleryimage_id_seq OWNED BY public.projects_projectpagegalleryimage.id;


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.taggit_tag OWNER TO andrew;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_tag_id_seq OWNER TO andrew;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.taggit_tag_id_seq OWNED BY public.taggit_tag.id;


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.taggit_taggeditem OWNER TO andrew;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_taggeditem_id_seq OWNER TO andrew;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.taggit_taggeditem_id_seq OWNED BY public.taggit_taggeditem.id;


--
-- Name: wagtailcore_collection; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_collection (
    id integer NOT NULL,
    path character varying(255) COLLATE pg_catalog."C" NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    name character varying(255) NOT NULL,
    CONSTRAINT wagtailcore_collection_depth_check CHECK ((depth >= 0)),
    CONSTRAINT wagtailcore_collection_numchild_check CHECK ((numchild >= 0))
);


ALTER TABLE public.wagtailcore_collection OWNER TO andrew;

--
-- Name: wagtailcore_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_collection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_collection_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_collection_id_seq OWNED BY public.wagtailcore_collection.id;


--
-- Name: wagtailcore_collectionviewrestriction; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_collectionviewrestriction (
    id integer NOT NULL,
    restriction_type character varying(20) NOT NULL,
    password character varying(255) NOT NULL,
    collection_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_collectionviewrestriction OWNER TO andrew;

--
-- Name: wagtailcore_collectionviewrestriction_groups; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_collectionviewrestriction_groups (
    id integer NOT NULL,
    collectionviewrestriction_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_collectionviewrestriction_groups OWNER TO andrew;

--
-- Name: wagtailcore_collectionviewrestriction_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_collectionviewrestriction_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_collectionviewrestriction_groups_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_collectionviewrestriction_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_collectionviewrestriction_groups_id_seq OWNED BY public.wagtailcore_collectionviewrestriction_groups.id;


--
-- Name: wagtailcore_collectionviewrestriction_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_collectionviewrestriction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_collectionviewrestriction_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_collectionviewrestriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_collectionviewrestriction_id_seq OWNED BY public.wagtailcore_collectionviewrestriction.id;


--
-- Name: wagtailcore_groupcollectionpermission; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_groupcollectionpermission (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_groupcollectionpermission OWNER TO andrew;

--
-- Name: wagtailcore_groupcollectionpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_groupcollectionpermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_groupcollectionpermission_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_groupcollectionpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_groupcollectionpermission_id_seq OWNED BY public.wagtailcore_groupcollectionpermission.id;


--
-- Name: wagtailcore_grouppagepermission; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_grouppagepermission (
    id integer NOT NULL,
    permission_type character varying(20) NOT NULL,
    group_id integer NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_grouppagepermission OWNER TO andrew;

--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_grouppagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_grouppagepermission_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_grouppagepermission_id_seq OWNED BY public.wagtailcore_grouppagepermission.id;


--
-- Name: wagtailcore_page; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_page (
    id integer NOT NULL,
    path character varying(255) COLLATE pg_catalog."C" NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    live boolean NOT NULL,
    has_unpublished_changes boolean NOT NULL,
    url_path text NOT NULL,
    seo_title character varying(255) NOT NULL,
    show_in_menus boolean NOT NULL,
    search_description text NOT NULL,
    go_live_at timestamp with time zone,
    expire_at timestamp with time zone,
    expired boolean NOT NULL,
    content_type_id integer NOT NULL,
    owner_id integer,
    locked boolean NOT NULL,
    latest_revision_created_at timestamp with time zone,
    first_published_at timestamp with time zone,
    live_revision_id integer,
    last_published_at timestamp with time zone,
    draft_title character varying(255) NOT NULL,
    CONSTRAINT wagtailcore_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT wagtailcore_page_numchild_check CHECK ((numchild >= 0))
);


ALTER TABLE public.wagtailcore_page OWNER TO andrew;

--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_page_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_page_id_seq OWNED BY public.wagtailcore_page.id;


--
-- Name: wagtailcore_pagerevision; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_pagerevision (
    id integer NOT NULL,
    submitted_for_moderation boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    content_json text NOT NULL,
    approved_go_live_at timestamp with time zone,
    page_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.wagtailcore_pagerevision OWNER TO andrew;

--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_pagerevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_pagerevision_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_pagerevision_id_seq OWNED BY public.wagtailcore_pagerevision.id;


--
-- Name: wagtailcore_pageviewrestriction; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_pageviewrestriction (
    id integer NOT NULL,
    password character varying(255) NOT NULL,
    page_id integer NOT NULL,
    restriction_type character varying(20) NOT NULL
);


ALTER TABLE public.wagtailcore_pageviewrestriction OWNER TO andrew;

--
-- Name: wagtailcore_pageviewrestriction_groups; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_pageviewrestriction_groups (
    id integer NOT NULL,
    pageviewrestriction_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_pageviewrestriction_groups OWNER TO andrew;

--
-- Name: wagtailcore_pageviewrestriction_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_pageviewrestriction_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_pageviewrestriction_groups_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_pageviewrestriction_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_pageviewrestriction_groups_id_seq OWNED BY public.wagtailcore_pageviewrestriction_groups.id;


--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_pageviewrestriction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_pageviewrestriction_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_pageviewrestriction_id_seq OWNED BY public.wagtailcore_pageviewrestriction.id;


--
-- Name: wagtailcore_site; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailcore_site (
    id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    port integer NOT NULL,
    is_default_site boolean NOT NULL,
    root_page_id integer NOT NULL,
    site_name character varying(255)
);


ALTER TABLE public.wagtailcore_site OWNER TO andrew;

--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailcore_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_site_id_seq OWNER TO andrew;

--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailcore_site_id_seq OWNED BY public.wagtailcore_site.id;


--
-- Name: wagtaildocs_document; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtaildocs_document (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    file character varying(100) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    uploaded_by_user_id integer,
    collection_id integer NOT NULL,
    file_size integer,
    file_hash character varying(40) NOT NULL,
    CONSTRAINT wagtaildocs_document_file_size_check CHECK ((file_size >= 0))
);


ALTER TABLE public.wagtaildocs_document OWNER TO andrew;

--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtaildocs_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtaildocs_document_id_seq OWNER TO andrew;

--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtaildocs_document_id_seq OWNED BY public.wagtaildocs_document.id;


--
-- Name: wagtailembeds_embed; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailembeds_embed (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    max_width smallint,
    type character varying(10) NOT NULL,
    html text NOT NULL,
    title text NOT NULL,
    author_name text NOT NULL,
    provider_name text NOT NULL,
    thumbnail_url character varying(200),
    width integer,
    height integer,
    last_updated timestamp with time zone NOT NULL
);


ALTER TABLE public.wagtailembeds_embed OWNER TO andrew;

--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailembeds_embed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailembeds_embed_id_seq OWNER TO andrew;

--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailembeds_embed_id_seq OWNED BY public.wagtailembeds_embed.id;


--
-- Name: wagtailforms_formsubmission; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailforms_formsubmission (
    id integer NOT NULL,
    form_data text NOT NULL,
    submit_time timestamp with time zone NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.wagtailforms_formsubmission OWNER TO andrew;

--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailforms_formsubmission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailforms_formsubmission_id_seq OWNER TO andrew;

--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailforms_formsubmission_id_seq OWNED BY public.wagtailforms_formsubmission.id;


--
-- Name: wagtailimages_image; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailimages_image (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    file character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    focal_point_x integer,
    focal_point_y integer,
    focal_point_width integer,
    focal_point_height integer,
    uploaded_by_user_id integer,
    file_size integer,
    collection_id integer NOT NULL,
    file_hash character varying(40) NOT NULL,
    CONSTRAINT wagtailimages_image_file_size_check CHECK ((file_size >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_height_check CHECK ((focal_point_height >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_width_check CHECK ((focal_point_width >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_x_check CHECK ((focal_point_x >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_y_check CHECK ((focal_point_y >= 0))
);


ALTER TABLE public.wagtailimages_image OWNER TO andrew;

--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailimages_image_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailimages_image_id_seq OWNER TO andrew;

--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailimages_image_id_seq OWNED BY public.wagtailimages_image.id;


--
-- Name: wagtailimages_rendition; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailimages_rendition (
    id integer NOT NULL,
    file character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    focal_point_key character varying(16) NOT NULL,
    image_id integer NOT NULL,
    filter_spec character varying(255) NOT NULL
);


ALTER TABLE public.wagtailimages_rendition OWNER TO andrew;

--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailimages_rendition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailimages_rendition_id_seq OWNER TO andrew;

--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailimages_rendition_id_seq OWNED BY public.wagtailimages_rendition.id;


--
-- Name: wagtailredirects_redirect; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailredirects_redirect (
    id integer NOT NULL,
    old_path character varying(255) NOT NULL,
    is_permanent boolean NOT NULL,
    redirect_link character varying(255) NOT NULL,
    redirect_page_id integer,
    site_id integer
);


ALTER TABLE public.wagtailredirects_redirect OWNER TO andrew;

--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailredirects_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailredirects_redirect_id_seq OWNER TO andrew;

--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailredirects_redirect_id_seq OWNED BY public.wagtailredirects_redirect.id;


--
-- Name: wagtailsearch_editorspick; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailsearch_editorspick (
    id integer NOT NULL,
    sort_order integer,
    description text NOT NULL,
    page_id integer NOT NULL,
    query_id integer NOT NULL
);


ALTER TABLE public.wagtailsearch_editorspick OWNER TO andrew;

--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailsearch_editorspick_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_editorspick_id_seq OWNER TO andrew;

--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailsearch_editorspick_id_seq OWNED BY public.wagtailsearch_editorspick.id;


--
-- Name: wagtailsearch_query; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailsearch_query (
    id integer NOT NULL,
    query_string character varying(255) NOT NULL
);


ALTER TABLE public.wagtailsearch_query OWNER TO andrew;

--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailsearch_query_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_query_id_seq OWNER TO andrew;

--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailsearch_query_id_seq OWNED BY public.wagtailsearch_query.id;


--
-- Name: wagtailsearch_querydailyhits; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailsearch_querydailyhits (
    id integer NOT NULL,
    date date NOT NULL,
    hits integer NOT NULL,
    query_id integer NOT NULL
);


ALTER TABLE public.wagtailsearch_querydailyhits OWNER TO andrew;

--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailsearch_querydailyhits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_querydailyhits_id_seq OWNER TO andrew;

--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailsearch_querydailyhits_id_seq OWNED BY public.wagtailsearch_querydailyhits.id;


--
-- Name: wagtailusers_userprofile; Type: TABLE; Schema: public; Owner: andrew
--

CREATE TABLE public.wagtailusers_userprofile (
    id integer NOT NULL,
    submitted_notifications boolean NOT NULL,
    approved_notifications boolean NOT NULL,
    rejected_notifications boolean NOT NULL,
    user_id integer NOT NULL,
    preferred_language character varying(10) NOT NULL,
    current_time_zone character varying(40) NOT NULL,
    avatar character varying(100) NOT NULL
);


ALTER TABLE public.wagtailusers_userprofile OWNER TO andrew;

--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: andrew
--

CREATE SEQUENCE public.wagtailusers_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailusers_userprofile_id_seq OWNER TO andrew;

--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: andrew
--

ALTER SEQUENCE public.wagtailusers_userprofile_id_seq OWNED BY public.wagtailusers_userprofile.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpagetag ALTER COLUMN id SET DEFAULT nextval('public.blog_blogpagetag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepageimagegallery ALTER COLUMN id SET DEFAULT nextval('public.home_homepageimagegallery_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_people ALTER COLUMN id SET DEFAULT nextval('public.home_people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_skills ALTER COLUMN id SET DEFAULT nextval('public.home_skills_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpagegalleryimage ALTER COLUMN id SET DEFAULT nextval('public.projects_projectpagegalleryimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_tag ALTER COLUMN id SET DEFAULT nextval('public.taggit_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_taggeditem ALTER COLUMN id SET DEFAULT nextval('public.taggit_taggeditem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collection ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_collection_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_collectionviewrestriction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction_groups ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_collectionviewrestriction_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_groupcollectionpermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_grouppagepermission ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_grouppagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pagerevision ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_pagerevision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_pageviewrestriction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction_groups ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_pageviewrestriction_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_site ALTER COLUMN id SET DEFAULT nextval('public.wagtailcore_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtaildocs_document ALTER COLUMN id SET DEFAULT nextval('public.wagtaildocs_document_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailembeds_embed ALTER COLUMN id SET DEFAULT nextval('public.wagtailembeds_embed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailforms_formsubmission ALTER COLUMN id SET DEFAULT nextval('public.wagtailforms_formsubmission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_image ALTER COLUMN id SET DEFAULT nextval('public.wagtailimages_image_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_rendition ALTER COLUMN id SET DEFAULT nextval('public.wagtailimages_rendition_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailredirects_redirect ALTER COLUMN id SET DEFAULT nextval('public.wagtailredirects_redirect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_editorspick ALTER COLUMN id SET DEFAULT nextval('public.wagtailsearch_editorspick_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_query ALTER COLUMN id SET DEFAULT nextval('public.wagtailsearch_query_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_querydailyhits ALTER COLUMN id SET DEFAULT nextval('public.wagtailsearch_querydailyhits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailusers_userprofile ALTER COLUMN id SET DEFAULT nextval('public.wagtailusers_userprofile_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_group (id, name) FROM stdin;
1	Moderators
2	Editors
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 2, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	2	1
5	2	2
6	2	3
7	1	4
8	1	5
9	1	6
10	2	4
11	2	5
12	2	6
13	1	7
14	2	7
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 14, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add image	2	add_image
2	Can change image	2	change_image
3	Can delete image	2	delete_image
4	Can add document	3	add_document
5	Can change document	3	change_document
6	Can delete document	3	delete_document
7	Can access Wagtail admin	4	access_admin
8	Can add blogpage tag	5	add_blogpagetag
9	Can change blogpage tag	5	change_blogpagetag
10	Can delete blogpage tag	5	delete_blogpagetag
11	Can add blog page gallery image	6	add_blogpagegalleryimage
12	Can change blog page gallery image	6	change_blogpagegalleryimage
13	Can delete blog page gallery image	6	delete_blogpagegalleryimage
14	Can add blogtag indexpage	7	add_blogtagindexpage
15	Can change blogtag indexpage	7	change_blogtagindexpage
16	Can delete blogtag indexpage	7	delete_blogtagindexpage
17	Can add blog indexpage	8	add_blogindexpage
18	Can change blog indexpage	8	change_blogindexpage
19	Can delete blog indexpage	8	delete_blogindexpage
20	Can add blogpage	9	add_blogpage
21	Can change blogpage	9	change_blogpage
22	Can delete blogpage	9	delete_blogpage
23	Can add home page image gallery	10	add_homepageimagegallery
24	Can change home page image gallery	10	change_homepageimagegallery
25	Can delete home page image gallery	10	delete_homepageimagegallery
26	Can add Person	11	add_people
27	Can change Person	11	change_people
28	Can delete Person	11	delete_people
29	Can add form field	12	add_formfield
30	Can change form field	12	change_formfield
31	Can delete form field	12	delete_formfield
32	Can add form page	13	add_formpage
33	Can change form page	13	change_formpage
34	Can delete form page	13	delete_formpage
35	Can add home page	14	add_homepage
36	Can change home page	14	change_homepage
37	Can delete home page	14	delete_homepage
38	Can add standard page	15	add_standardpage
39	Can change standard page	15	change_standardpage
40	Can delete standard page	15	delete_standardpage
41	Can add project index page	16	add_projectindexpage
42	Can change project index page	16	change_projectindexpage
43	Can delete project index page	16	delete_projectindexpage
44	Can add projectpage	17	add_projectpage
45	Can change projectpage	17	change_projectpage
46	Can delete projectpage	17	delete_projectpage
47	Can add project page gallery image	18	add_projectpagegalleryimage
48	Can change project page gallery image	18	change_projectpagegalleryimage
49	Can delete project page gallery image	18	delete_projectpagegalleryimage
50	Can add form submission	19	add_formsubmission
51	Can change form submission	19	change_formsubmission
52	Can delete form submission	19	delete_formsubmission
53	Can add redirect	20	add_redirect
54	Can change redirect	20	change_redirect
55	Can delete redirect	20	delete_redirect
56	Can add embed	21	add_embed
57	Can change embed	21	change_embed
58	Can delete embed	21	delete_embed
59	Can add user profile	22	add_userprofile
60	Can change user profile	22	change_userprofile
61	Can delete user profile	22	delete_userprofile
62	Can add rendition	23	add_rendition
63	Can change rendition	23	change_rendition
64	Can delete rendition	23	delete_rendition
65	Can add query	24	add_query
66	Can change query	24	change_query
67	Can delete query	24	delete_query
68	Can add Query Daily Hits	25	add_querydailyhits
69	Can change Query Daily Hits	25	change_querydailyhits
70	Can delete Query Daily Hits	25	delete_querydailyhits
71	Can add page	1	add_page
72	Can change page	1	change_page
73	Can delete page	1	delete_page
74	Can add group collection permission	26	add_groupcollectionpermission
75	Can change group collection permission	26	change_groupcollectionpermission
76	Can delete group collection permission	26	delete_groupcollectionpermission
77	Can add site	27	add_site
78	Can change site	27	change_site
79	Can delete site	27	delete_site
80	Can add collection	28	add_collection
81	Can change collection	28	change_collection
82	Can delete collection	28	delete_collection
83	Can add page view restriction	29	add_pageviewrestriction
84	Can change page view restriction	29	change_pageviewrestriction
85	Can delete page view restriction	29	delete_pageviewrestriction
86	Can add page revision	30	add_pagerevision
87	Can change page revision	30	change_pagerevision
88	Can delete page revision	30	delete_pagerevision
89	Can add group page permission	31	add_grouppagepermission
90	Can change group page permission	31	change_grouppagepermission
91	Can delete group page permission	31	delete_grouppagepermission
92	Can add collection view restriction	32	add_collectionviewrestriction
93	Can change collection view restriction	32	change_collectionviewrestriction
94	Can delete collection view restriction	32	delete_collectionviewrestriction
95	Can add Tag	33	add_tag
96	Can change Tag	33	change_tag
97	Can delete Tag	33	delete_tag
98	Can add Tagged Item	34	add_taggeditem
99	Can change Tagged Item	34	change_taggeditem
100	Can delete Tagged Item	34	delete_taggeditem
101	Can add log entry	35	add_logentry
102	Can change log entry	35	change_logentry
103	Can delete log entry	35	delete_logentry
104	Can add user	36	add_user
105	Can change user	36	change_user
106	Can delete user	36	delete_user
107	Can add permission	37	add_permission
108	Can change permission	37	change_permission
109	Can delete permission	37	delete_permission
110	Can add group	38	add_group
111	Can change group	38	change_group
112	Can delete group	38	delete_group
113	Can add content type	39	add_contenttype
114	Can change content type	39	change_contenttype
115	Can delete content type	39	delete_contenttype
116	Can add session	40	add_session
117	Can change session	40	change_session
118	Can delete session	40	delete_session
119	Can add skills	41	add_skills
120	Can change skills	41	change_skills
121	Can delete skills	41	delete_skills
122	Can view blogpage	9	view_blogpage
123	Can view blogtag indexpage	7	view_blogtagindexpage
124	Can view blogpage tag	5	view_blogpagetag
125	Can view blog indexpage	8	view_blogindexpage
126	Can view Person	11	view_people
127	Can view home page image gallery	10	view_homepageimagegallery
128	Can view skills	41	view_skills
129	Can view home page	14	view_homepage
130	Can view standard page	15	view_standardpage
131	Can view project page gallery image	18	view_projectpagegalleryimage
132	Can view projectpage	17	view_projectpage
133	Can view project index page	16	view_projectindexpage
134	Can view form submission	19	view_formsubmission
135	Can view redirect	20	view_redirect
136	Can view embed	21	view_embed
137	Can view user profile	22	view_userprofile
138	Can view document	3	view_document
139	Can view rendition	23	view_rendition
140	Can view image	2	view_image
141	Can view Query Daily Hits	25	view_querydailyhits
142	Can view query	24	view_query
143	Can view page revision	30	view_pagerevision
144	Can view page	1	view_page
145	Can view page view restriction	29	view_pageviewrestriction
146	Can view group collection permission	26	view_groupcollectionpermission
147	Can view site	27	view_site
148	Can view collection view restriction	32	view_collectionviewrestriction
149	Can view collection	28	view_collection
150	Can view group page permission	31	view_grouppagepermission
151	Can view Tagged Item	34	view_taggeditem
152	Can view Tag	33	view_tag
153	Can view log entry	35	view_logentry
154	Can view permission	37	view_permission
155	Can view group	38	view_group
156	Can view user	36	view_user
157	Can view content type	39	view_contenttype
158	Can view session	40	view_session
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 158, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$120000$ES7vXHQRDbQx$iG6jRJvNwsdsVOvl4iU3oq13dQWIXOJl26HA9Olu3g4=	2019-02-19 20:13:45.599421+00	t	admin			andrewktelleria@gmail.com	t	t	2018-08-17 00:43:26.242887+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: blog_blogindexpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.blog_blogindexpage (page_ptr_id, intro) FROM stdin;
6	<p>Hey! Thanks for checking out my blog. I hope you find some of the things I wrote about helpful and interesting.</p>
\.


--
-- Data for Name: blog_blogpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.blog_blogpage (page_ptr_id, feature, date, intro, body, author_id, image_id) FROM stdin;
9	1	2018-11-01	My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.	[{"value": "<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django is you write views and your urls pick which view to execute. </p>", "type": "paragraph", "id": "76bb64af-208c-45f4-8e0a-9d41c7642df6"}]	\N	16
10	0	2019-02-19	How I use GIT on my projects.	[{"id": "08a851fe-3fae-4907-801c-79a90f662e32", "type": "paragraph_block", "value": "<p> </p><p><b>Team Git Workflow</b></p><p>This is suppose to give a general idea on how a team git workflow should be. You can take this approach and apply it to anything that you are working on in a team environment. Git is a wonderful technology and has made it easy to keep everyone working on the project up to date with the code base.</p><p>Clone your repo to your local machine.</p><p>Switch to dev branch, if dev branch has not been created on remote repo use git checkout and set upstream. Verify dev branch is on remote repo.</p><p>Create a feature branch and name it the feature you are working on.</p><p>Usually there are multiple parts that make up a feature in a team environment, create the main-feature-branch and branch off into parts of the feature. </p><p>E.g. Main-feature-branch =&gt; shopping_cart</p><p>Sub-feature-branch =&gt; shopping_cart_logic</p><p>Sub-feature-branch =&gt; shopping_cart_styling</p><p>(In this example it would be a good idea to have the HTML in place before the sub branches are created)</p><p>Set upstream and push your initial commit.</p><p>Develop bits of the feature and commit the bits; push them to the remote repository.</p><p>Finish the feature and push the final changes to the remote repo; submit merge request on remote repo for the sub-feature-branch.</p><p>Merge sub-feature-branch into main-feature-branch on remote repository.</p><p>Delete your sub-feature-branch from local repo and from remote repo.</p><ol><li>git branch -d branch-name</li><li>git push origin \\u2014delete branch-name</li></ol><p>All parts of the main-feature-branch have been completed then submit merge request to dev branch. Merge the main-feature-branch into dev branch.</p><p>Delete the main-feature-branch.</p><p>Checkout into dev branch on local machine and pull down changes from remote repo dev branch to your local dev branch.</p><p>Rinse and repeat. Go back to the step where you branch off the dev branch into your feature branch.</p>"}]	\N	\N
\.


--
-- Data for Name: blog_blogpagetag; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.blog_blogpagetag (id, content_object_id, tag_id) FROM stdin;
1	9	1
2	9	2
3	9	3
4	9	4
\.


--
-- Name: blog_blogpagetag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.blog_blogpagetag_id_seq', 4, true);


--
-- Data for Name: blog_blogtagindexpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.blog_blogtagindexpage (page_ptr_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	wagtailcore	page
2	wagtailimages	image
3	wagtaildocs	document
4	wagtailadmin	admin
5	blog	blogpagetag
6	blog	blogpagegalleryimage
7	blog	blogtagindexpage
8	blog	blogindexpage
9	blog	blogpage
10	home	homepageimagegallery
11	home	people
12	home	formfield
13	home	formpage
14	home	homepage
15	home	standardpage
16	projects	projectindexpage
17	projects	projectpage
18	projects	projectpagegalleryimage
19	wagtailforms	formsubmission
20	wagtailredirects	redirect
21	wagtailembeds	embed
22	wagtailusers	userprofile
23	wagtailimages	rendition
24	wagtailsearch	query
25	wagtailsearch	querydailyhits
26	wagtailcore	groupcollectionpermission
27	wagtailcore	site
28	wagtailcore	collection
29	wagtailcore	pageviewrestriction
30	wagtailcore	pagerevision
31	wagtailcore	grouppagepermission
32	wagtailcore	collectionviewrestriction
33	taggit	tag
34	taggit	taggeditem
35	admin	logentry
36	auth	user
37	auth	permission
38	auth	group
39	contenttypes	contenttype
40	sessions	session
41	home	skills
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 41, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-08-17 00:37:52.259372+00
2	auth	0001_initial	2018-08-17 00:37:52.339105+00
3	admin	0001_initial	2018-08-17 00:37:52.364547+00
4	admin	0002_logentry_remove_auto_add	2018-08-17 00:37:52.37429+00
5	contenttypes	0002_remove_content_type_name	2018-08-17 00:37:52.396095+00
6	auth	0002_alter_permission_name_max_length	2018-08-17 00:37:52.402509+00
7	auth	0003_alter_user_email_max_length	2018-08-17 00:37:52.41298+00
8	auth	0004_alter_user_username_opts	2018-08-17 00:37:52.42242+00
9	auth	0005_alter_user_last_login_null	2018-08-17 00:37:52.432955+00
10	auth	0006_require_contenttypes_0002	2018-08-17 00:37:52.434895+00
11	auth	0007_alter_validators_add_error_messages	2018-08-17 00:37:52.444173+00
12	auth	0008_alter_user_username_max_length	2018-08-17 00:37:52.460183+00
13	auth	0009_alter_user_last_name_max_length	2018-08-17 00:37:52.47024+00
14	taggit	0001_initial	2018-08-17 00:37:52.508778+00
15	wagtailimages	0001_initial	2018-08-17 00:37:52.571047+00
16	wagtailcore	0001_initial	2018-08-17 00:37:52.814861+00
17	wagtailcore	0002_initial_data	2018-08-17 00:37:52.816985+00
18	wagtailcore	0003_add_uniqueness_constraint_on_group_page_permission	2018-08-17 00:37:52.818665+00
19	wagtailcore	0004_page_locked	2018-08-17 00:37:52.820355+00
20	wagtailcore	0005_add_page_lock_permission_to_moderators	2018-08-17 00:37:52.822207+00
21	wagtailcore	0006_add_lock_page_permission	2018-08-17 00:37:52.823903+00
22	wagtailcore	0007_page_latest_revision_created_at	2018-08-17 00:37:52.82562+00
23	wagtailcore	0008_populate_latest_revision_created_at	2018-08-17 00:37:52.827493+00
24	wagtailcore	0009_remove_auto_now_add_from_pagerevision_created_at	2018-08-17 00:37:52.829289+00
25	wagtailcore	0010_change_page_owner_to_null_on_delete	2018-08-17 00:37:52.83106+00
26	wagtailcore	0011_page_first_published_at	2018-08-17 00:37:52.83293+00
27	wagtailcore	0012_extend_page_slug_field	2018-08-17 00:37:52.834758+00
28	wagtailcore	0013_update_golive_expire_help_text	2018-08-17 00:37:52.836513+00
29	wagtailcore	0014_add_verbose_name	2018-08-17 00:37:52.838226+00
30	wagtailcore	0015_add_more_verbose_names	2018-08-17 00:37:52.839938+00
31	wagtailcore	0016_change_page_url_path_to_text_field	2018-08-17 00:37:52.841795+00
32	wagtailimages	0002_initial_data	2018-08-17 00:37:52.877932+00
33	wagtailimages	0003_fix_focal_point_fields	2018-08-17 00:37:52.930847+00
34	wagtailimages	0004_make_focal_point_key_not_nullable	2018-08-17 00:37:52.960851+00
35	wagtailimages	0005_make_filter_spec_unique	2018-08-17 00:37:52.976681+00
36	wagtailimages	0006_add_verbose_names	2018-08-17 00:37:53.029792+00
37	wagtailimages	0007_image_file_size	2018-08-17 00:37:53.04527+00
38	wagtailimages	0008_image_created_at_index	2018-08-17 00:37:53.063255+00
39	wagtailimages	0009_capitalizeverbose	2018-08-17 00:37:53.162183+00
40	wagtailimages	0010_change_on_delete_behaviour	2018-08-17 00:37:53.182825+00
41	wagtailcore	0017_change_edit_page_permission_description	2018-08-17 00:37:53.194939+00
42	wagtailcore	0018_pagerevision_submitted_for_moderation_index	2018-08-17 00:37:53.211752+00
43	wagtailcore	0019_verbose_names_cleanup	2018-08-17 00:37:53.307998+00
44	wagtailcore	0020_add_index_on_page_first_published_at	2018-08-17 00:37:53.326966+00
45	wagtailcore	0021_capitalizeverbose	2018-08-17 00:37:53.698653+00
46	wagtailcore	0022_add_site_name	2018-08-17 00:37:53.713757+00
47	wagtailcore	0023_alter_page_revision_on_delete_behaviour	2018-08-17 00:37:53.732542+00
48	wagtailcore	0024_collection	2018-08-17 00:37:53.74842+00
49	wagtailcore	0025_collection_initial_data	2018-08-17 00:37:53.771475+00
50	wagtailcore	0026_group_collection_permission	2018-08-17 00:37:53.812888+00
51	wagtailimages	0011_image_collection	2018-08-17 00:37:53.849961+00
52	wagtailimages	0012_copy_image_permissions_to_collections	2018-08-17 00:37:53.881876+00
53	wagtailimages	0013_make_rendition_upload_callable	2018-08-17 00:37:53.89208+00
54	wagtailimages	0014_add_filter_spec_field	2018-08-17 00:37:53.94201+00
55	wagtailimages	0015_fill_filter_spec_field	2018-08-17 00:37:53.964207+00
56	wagtailimages	0016_deprecate_rendition_filter_relation	2018-08-17 00:37:54.013505+00
57	wagtailimages	0017_reduce_focal_point_key_max_length	2018-08-17 00:37:54.040438+00
58	wagtailimages	0018_remove_rendition_filter	2018-08-17 00:37:54.122942+00
59	wagtailimages	0019_delete_filter	2018-08-17 00:37:54.127995+00
60	wagtailimages	0020_add-verbose-name	2018-08-17 00:37:54.143255+00
61	taggit	0002_auto_20150616_2121	2018-08-17 00:37:54.156299+00
62	wagtaildocs	0001_initial	2018-08-17 00:37:54.180615+00
63	wagtaildocs	0002_initial_data	2018-08-17 00:37:54.216292+00
64	wagtaildocs	0003_add_verbose_names	2018-08-17 00:37:54.26113+00
65	wagtaildocs	0004_capitalizeverbose	2018-08-17 00:37:54.347816+00
66	wagtaildocs	0005_document_collection	2018-08-17 00:37:54.379269+00
67	wagtaildocs	0006_copy_document_permissions_to_collections	2018-08-17 00:37:54.410423+00
68	wagtaildocs	0005_alter_uploaded_by_user_on_delete_action	2018-08-17 00:37:54.431867+00
69	wagtaildocs	0007_merge	2018-08-17 00:37:54.433886+00
70	wagtailcore	0027_fix_collection_path_collation	2018-08-17 00:37:54.459609+00
71	wagtailcore	0024_alter_page_content_type_on_delete_behaviour	2018-08-17 00:37:54.483178+00
72	wagtailcore	0028_merge	2018-08-17 00:37:54.485291+00
73	wagtailcore	0029_unicode_slugfield_dj19	2018-08-17 00:37:54.499491+00
74	wagtailcore	0030_index_on_pagerevision_created_at	2018-08-17 00:37:54.516388+00
75	wagtailcore	0031_add_page_view_restriction_types	2018-08-17 00:37:54.584082+00
76	wagtailcore	0032_add_bulk_delete_page_permission	2018-08-17 00:37:54.599039+00
77	wagtailcore	0033_remove_golive_expiry_help_text	2018-08-17 00:37:54.626485+00
78	wagtailcore	0034_page_live_revision	2018-08-17 00:37:54.646099+00
79	wagtailcore	0035_page_last_published_at	2018-08-17 00:37:54.661244+00
80	wagtailcore	0036_populate_page_last_published_at	2018-08-17 00:37:54.685521+00
81	wagtailcore	0037_set_page_owner_editable	2018-08-17 00:37:54.705178+00
82	wagtailcore	0038_make_first_published_at_editable	2018-08-17 00:37:54.719391+00
83	wagtailcore	0039_collectionviewrestriction	2018-08-17 00:37:54.7931+00
84	wagtailcore	0040_page_draft_title	2018-08-17 00:37:54.860645+00
85	home	0001_initial	2018-08-17 00:37:55.254722+00
86	blog	0001_initial	2018-08-17 00:37:55.433179+00
87	blog	0002_auto_20180726_0040	2018-08-17 00:37:55.532083+00
88	wagtailredirects	0001_initial	2018-08-17 00:37:55.585043+00
89	wagtailredirects	0002_add_verbose_names	2018-08-17 00:37:55.646049+00
90	wagtailredirects	0003_make_site_field_editable	2018-08-17 00:37:55.762795+00
91	wagtailredirects	0004_set_unique_on_path_and_site	2018-08-17 00:37:55.809673+00
92	wagtailredirects	0005_capitalizeverbose	2018-08-17 00:37:55.955423+00
93	wagtailforms	0001_initial	2018-08-17 00:37:55.997787+00
94	wagtailforms	0002_add_verbose_names	2018-08-17 00:37:56.03774+00
95	wagtailforms	0003_capitalizeverbose	2018-08-17 00:37:56.077861+00
96	home	0002_auto_20180726_0048	2018-08-17 00:37:56.206187+00
97	home	0003_auto_20180730_1802	2018-08-17 00:37:56.498566+00
98	home	0004_auto_20180730_2024	2018-08-17 00:37:56.611867+00
99	home	0005_auto_20180730_2025	2018-08-17 00:37:56.700915+00
100	home	0006_auto_20180801_2102	2018-08-17 00:37:56.83817+00
101	home	0007_auto_20180801_2124	2018-08-17 00:37:57.311914+00
102	home	0008_auto_20180802_1645	2018-08-17 00:37:57.524299+00
103	home	0009_auto_20180803_2312	2018-08-17 00:37:57.617234+00
104	projects	0001_initial	2018-08-17 00:37:57.701484+00
105	projects	0002_projectpagegalleryimage	2018-08-17 00:37:57.749246+00
106	projects	0003_auto_20180808_1125	2018-08-17 00:37:57.887063+00
107	sessions	0001_initial	2018-08-17 00:37:57.903078+00
108	wagtailadmin	0001_create_admin_access_permissions	2018-08-17 00:37:57.954475+00
109	wagtailembeds	0001_initial	2018-08-17 00:37:57.973403+00
110	wagtailembeds	0002_add_verbose_names	2018-08-17 00:37:57.979099+00
111	wagtailembeds	0003_capitalizeverbose	2018-08-17 00:37:57.984586+00
112	wagtailsearch	0001_initial	2018-08-17 00:37:58.099909+00
113	wagtailsearch	0002_add_verbose_names	2018-08-17 00:37:58.198823+00
114	wagtailsearch	0003_remove_editors_pick	2018-08-17 00:37:58.240433+00
115	wagtailusers	0001_initial	2018-08-17 00:37:58.286296+00
116	wagtailusers	0002_add_verbose_name_on_userprofile	2018-08-17 00:37:58.328369+00
117	wagtailusers	0003_add_verbose_names	2018-08-17 00:37:58.345394+00
118	wagtailusers	0004_capitalizeverbose	2018-08-17 00:37:58.404739+00
119	wagtailusers	0005_make_related_name_wagtail_specific	2018-08-17 00:37:58.442954+00
120	wagtailusers	0006_userprofile_prefered_language	2018-08-17 00:37:58.466827+00
121	wagtailusers	0007_userprofile_current_time_zone	2018-08-17 00:37:58.491932+00
122	wagtailusers	0008_userprofile_avatar	2018-08-17 00:37:58.515312+00
123	wagtailcore	0001_squashed_0016_change_page_url_path_to_text_field	2018-08-17 00:37:58.518857+00
124	blog	0003_auto_20180906_1541	2018-09-06 22:41:34.185595+00
125	home	0010_auto_20181025_1520	2018-10-25 22:39:00.408451+00
126	home	0011_auto_20181025_1548	2018-10-25 22:50:55.425837+00
127	projects	0004_auto_20181025_1548	2018-10-25 22:50:55.48258+00
128	admin	0003_logentry_add_action_flag_choices	2019-02-19 20:10:04.270856+00
129	blog	0004_auto_20190219_1156	2019-02-19 20:10:04.343876+00
130	home	0012_auto_20190219_1142	2019-02-19 20:10:04.38976+00
131	home	0013_auto_20190219_1156	2019-02-19 20:10:04.50684+00
132	wagtailcore	0041_group_collection_permissions_verbose_name_plural	2019-02-19 20:10:04.52397+00
133	wagtaildocs	0008_document_file_size	2019-02-19 20:10:04.543085+00
134	wagtaildocs	0009_document_verbose_name_plural	2019-02-19 20:10:04.559866+00
135	wagtaildocs	0010_document_file_hash	2019-02-19 20:10:04.630106+00
136	wagtailembeds	0004_embed_verbose_name_plural	2019-02-19 20:10:04.636526+00
137	wagtailimages	0021_image_file_hash	2019-02-19 20:10:04.669573+00
138	wagtailredirects	0006_redirect_increase_max_length	2019-02-19 20:10:04.693879+00
139	wagtailsearch	0004_querydailyhits_verbose_name_plural	2019-02-19 20:10:04.700177+00
140	wagtailusers	0009_userprofile_verbose_name_plural	2019-02-19 20:10:04.71537+00
141	wagtailimages	0001_squashed_0021	2019-02-19 20:10:04.719012+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 141, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
y133ggl0cg1a7xuq96x2ziwrqizivww5	ZDQxZWEwNDU1NWQ0YzFiNzM2MjViZjYxZjVmYTA1ZDBlYTZjMTM4NTp7Il9hdXRoX3VzZXJfaGFzaCI6Ijk5NDg0MGExYWU5NDcwMTEwZTZiYzBkNDc4MDQyY2JiNDRjMDZiZGYiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2018-08-31 00:44:04.830519+00
7zy6r0rodlruo4m94xa4rvva8qnxt9vo	MTEyOGRlZTAzODM2OWJjY2FmZWYyYjEwNGNhMTJjMmFjMjM5MTk2ODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOTk0ODQwYTFhZTk0NzAxMTBlNmJjMGQ0NzgwNDJjYmI0NGMwNmJkZiIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-08-31 16:22:31.101472+00
vfuz61oy5tx7mfpzef8gbmdjivxdrv3s	Y2I1MzM2Mzg1OTQyNmRkZWM2NTZkYmEzYmRkODZjODVjODZiZmM1Zjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI5OTQ4NDBhMWFlOTQ3MDExMGU2YmMwZDQ3ODA0MmNiYjQ0YzA2YmRmIn0=	2018-09-20 23:06:42.991207+00
2s8x2gdpcskgqm7n5pfe0a3s5ho8mjow	Y2Q2ODQzYmQ3OTYxNmFkMGMzN2FmMzJiYmFkNzQzYTFkMGViOWY3Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5OTQ4NDBhMWFlOTQ3MDExMGU2YmMwZDQ3ODA0MmNiYjQ0YzA2YmRmIn0=	2018-09-24 15:06:46.721447+00
sksv6wempsquupnxgu5whtudp1ox4zyt	Njk3MTFhM2U0NWU4ZDY0MGFkNTMwMjMxYWYxNjNhNjQzMmQyZDJhZjp7Il9hdXRoX3VzZXJfaGFzaCI6Ijk5NDg0MGExYWU5NDcwMTEwZTZiYzBkNDc4MDQyY2JiNDRjMDZiZGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwid2FndGFpbC1wcmV2aWV3LTkiOlsidGl0bGU9QStDTVMrdGhhdCttYWtlcytzZW5zZSZib2R5LTAtaWQ9NTdiZTdiMDktZWU3Yy00YWFlLThmOTgtNjJiZWJmZDFkOWMxJmJvZHktY291bnQ9MSZpbWFnZT0xOSZleHBpcmVfYXQ9Jm5leHQ9JnRhZ3M9JTIyd2ViK2RldmVsb3BtZW50JTIyJTJDZGphbmdvJTJDcHl0aG9uJTJDd2FndGFpbCZnb19saXZlX2F0PSZmZWF0dXJlPTEmYXV0aG9yPSZib2R5LTAtb3JkZXI9MCZpbnRybz1NeStleHBlcmllbmNlK3dvcmtpbmcrd2l0aCtXYWd0YWlsK2hhcytiZWVuK2ErbG90K29mK2Z1bi4rSStlbmpveSt3b3JraW5nK3dpdGgrUHl0aG9uK2FuZCtXYWd0YWlsJTI3cytDTVMraXMrZnVuK3RvK3dvcmsrd2l0aCt0b28uJnNsdWc9Y21zLW1ha2VzLXNlbnNlJnNlb190aXRsZT0mZGF0ZT0yMDE4LTExLTAxJmJvZHktMC12YWx1ZT0lN0IlMEQlMEErKysrJTIyZW50aXR5TWFwJTIyJTNBKyU3QiUwRCUwQSsrKysrKysrJTIyMCUyMiUzQSslN0IlMEQlMEErKysrKysrKysrKyslMjJtdXRhYmlsaXR5JTIyJTNBKyUyMk1VVEFCTEUlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMkxJTkslMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJkYXRhJTIyJTNBKyU3QiUwRCUwQSsrKysrKysrKysrKysrKyslMjJ1cmwlMjIlM0ErJTIyaHR0cHMlM0ElMkYlMkZ3YWd0YWlsLmlvJTJGJTIyJTBEJTBBKysrKysrKysrKysrJTdEJTBEJTBBKysrKysrKyslN0QlMEQlMEErKysrJTdEJTJDJTBEJTBBKysrKyUyMmJsb2NrcyUyMiUzQSslNUIlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyV2FndGFpbCtpcythbithbWF6aW5nK0NNUyt0aGF0K2lzK2J1aWx0K29uK3RvcCtvZitEamFuZ28uK0NvbWluZytmcm9tK2ErUHl0aG9uK2JhY2tncm91bmQrSSt3YXMrbG9va2luZytmb3IrYStDTVMrdGhhdCt3YXMrYnVpbHQrd2l0aCtQeXRob24uK0krd2FzK3RhbGtpbmcrdG8rYStmcmllbmQrb2YrbWluZSt3aG8raXMrYWxzbythK2RldmVsb3Blcit0b2xkK21lK3RvK2xvb2sraW50byt1c2luZytXYWd0YWlsK2FuZCtoZStoYWQrd29ya2VkK3dpdGgraXQrYXQrd29yay4rSStkaWQrbXkrZHVlK2RpbGlnZW5jZSthbmQraW52ZXN0aWdhdGVkK3doYXQrV2FndGFpbCt3YXMrYWxsK2Fib3V0LitJK2dvdCtpbnRvK3RoZWlyK2RvY3MrYW5kK3dlbnQrdGhyb3VnaCt0aGVpcit0dXRvcmlhbCtvbitob3crdG8rYnVpbGQrYStibG9nLitJbW1lZGlhdGVseStJK2NvdWxkK3RlbGwrdGhhdCtJK3dhcytnb2luZyt0bytlbmpveSt3b3JraW5nK3dpdGgrV2FndGFpbC4rQStjb3VwbGUrdGhpbmdzK3dlcmUrdGhyb3dpbmcrbWUrb2ZmK3Rob3VnaCthbmQrdGhhdCt3YXMrdGhlK3VybHMrYW5kK3ZpZXdzLitJK2RpZCtub3QraGF2ZSt0byt3cml0ZSt1cmxzK29yK3ZpZXdzLitUaGF0K3dhcyt3ZWlyZCt0byttZStiZWNhdXNlK3RoYXQraXMrd2hhdCt5b3UrZG8rd2l0aCtEamFuZ28lMkMreW91K3dyaXRlK3ZpZXdzK2FuZCt5b3VyK3VybHMrcGljayt3aGljaCt2aWV3K3RvK3J1bi4lMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTJDJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiUwRCUwQSsrKysrKysrKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKysrKysrKysrKyUyMmxlbmd0aCUyMiUzQSs3JTJDJTBEJTBBKysrKysrKysrKysrKysrKysrKyslMjJvZmZzZXQlMjIlM0ErMCUyQyUwRCUwQSsrKysrKysrKysrKysrKysrKysrJTIya2V5JTIyJTNBKzAlMEQlMEErKysrKysrKysrKysrKysrJTdEJTBEJTBBKysrKysrKysrKysrJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJ1YXVvMSUyMiUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMkMlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJkc2JhOSUyMiUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMkErY29vbCtmZWF0dXJlK29mK1dhZ3RhaWwraXMrdGhhdCtpdCtjYW4rd29yaythbG9uZyt3aXRoK3lvdStEamFuZ28rYXBwbGljYXRpb24uK0Zyb20rdGhlaXIrd2Vic2l0ZSslNUMlMjJpdCt3aWxsK3BsYXkrbmljZWx5K3dpdGgrZXZlcnl0aGluZytpbit5b3VyK3RlY2grc3RhY2slNUMlMjIuK0l0K2NhbithbHNvK2JlK3VzZWQrYXMrYSttaWNyby1zZXJ2aWNlK3dpdGgraXRzK2J1aWx0K2luK0FQSStzbyt5b3UrY2FuK3dvcmsrd2l0aCt5b3VyK2Zyb250K2VuZCtmcmFtZXdvcmsrb2YrY2hvaWNlLitJK3RydWx5K2JlbGlldmUraXQlMjdzK2J1aWx0K2ZvcitldmVyeW9uZSt0aGF0K3dpbGwrZW5jb3VudGVyK2l0K2Zyb20rdGhlK2RldmVsb3Blcit0byt0aGUrY29udGVudCtlZGl0b3IuK0l0cytvcGVuK3NvdXJjZSthbmQrYW1hemluZy4rQXMreW91K2Nhbit0ZWxsK0krYW0rZXhjaXRlZCthYm91dCt0aGlzK3RlY2hub2xvZ3kuJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMnV2eTJmJTIyJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMnZjcjc0JTIyJTBEJTBBKysrKysrKyslN0QlMEQlMEErKysrJTVEJTBEJTBBJTdEJmNzcmZtaWRkbGV3YXJldG9rZW49UjlwS0hMZGlTSFhjZVEwZTQ2S0x5SzlCUGREV0xFV29YSU94NXIyNWhRR1pCbnJ2UUxkT3pKQklLWlJiTTFXWCZib2R5LTAtdHlwZT1wYXJhZ3JhcGgmYm9keS0wLWRlbGV0ZWQ9JnNlYXJjaF9kZXNjcmlwdGlvbj0iLDE1NDExMDQzNzUuODM1NDQwNl19	2018-11-15 20:32:55.863079+00
4uldz6915vp3e268k5tmshl55b53y0bm	MTBlOTViMTRiY2QwOTg2MTk4NzZjMGE0Yzk5MjkwYzE1ODk1NmU0MTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiJmZDk1MGExMGI1ZDkxZjI5NTE4OGIzNjZiNGRiZjE5YTBlYmIyODQ1Iiwid2FndGFpbC1wcmV2aWV3LTEwIjpbImJvZHktMC1vcmRlcj0wJmludHJvPUhvdytJK3VzZStHSVQrb24rbXkrcHJvamVjdHMuJmNzcmZtaWRkbGV3YXJldG9rZW49a1ZvRnhxQ3JPM01aV1pxY29PbjkwZTdGME03Yk1lSXdlZ1o5M1RBT20wV0R5NWdmV0NVdTFWbXBtNUtYTXkwYiZhdXRob3I9JmRhdGU9MjAxOS0wMi0xOSZleHBpcmVfYXQ9JnNsdWc9Z2l0LXdvcmtmbG93JnNlYXJjaF9kZXNjcmlwdGlvbj0mYm9keS1jb3VudD0xJmJvZHktMC10eXBlPXBhcmFncmFwaF9ibG9jayZmZWF0dXJlPTAmYm9keS0wLWRlbGV0ZWQ9Jm5leHQ9JmdvX2xpdmVfYXQ9JnNlb190aXRsZT0mYm9keS0wLWlkPTkwZDA5NWYzLTM4OTItNDFmZC1hNGFkLTA3MzY2N2MxMTA2NyZ0YWdzPSZ0aXRsZT1HaXQrV29ya2Zsb3cmaW1hZ2U9JmJvZHktMC12YWx1ZT0lN0IlMEQlMEErKysrJTIyYmxvY2tzJTIyJTNBKyU1QiUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJzZ3pybSUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJ2eGdxdiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyVGVhbStHaXQrV29ya2Zsb3clMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTBEJTBBKysrKysrKysrKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKysrKysrKysrJTIyb2Zmc2V0JTIyJTNBKzAlMkMlMEQlMEErKysrKysrKysrKysrKysrKysrKyUyMmxlbmd0aCUyMiUzQSsxNyUyQyUwRCUwQSsrKysrKysrKysrKysrKysrKysrJTIyc3R5bGUlMjIlM0ErJTIyQk9MRCUyMiUwRCUwQSsrKysrKysrKysrKysrKyslN0QlMEQlMEErKysrKysrKysrKyslNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIybXlpb3clMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMlRoaXMraXMrc3VwcG9zZSt0bytnaXZlK2ErZ2VuZXJhbCtpZGVhK29uK2hvdythK3RlYW0rZ2l0K3dvcmtmbG93K3Nob3VsZCtiZS4rWW91K2Nhbit0YWtlK3RoaXMrYXBwcm9hY2grYW5kK2FwcGx5K2l0K3RvK2FueXRoaW5nK3RoYXQreW91K2FyZSt3b3JraW5nK29uK2luK2ErdGVhbStlbnZpcm9ubWVudC4rR2l0K2lzK2Erd29uZGVyZnVsK3RlY2hub2xvZ3krYW5kK2hhcyttYWRlK2l0K2Vhc3krdG8ra2VlcCtldmVyeW9uZSt3b3JraW5nK29uK3RoZStwcm9qZWN0K3VwK3RvK2RhdGUrd2l0aCt0aGUrY29kZStiYXNlLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIyNGFzMGYlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMkNsb25lK3lvdXIrcmVwbyt0byt5b3VyK2xvY2FsK21hY2hpbmUuJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjIwZWhrNCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyU3dpdGNoK3RvK2RlditicmFuY2glMkMraWYrZGV2K2JyYW5jaCtoYXMrbm90K2JlZW4rY3JlYXRlZCtvbityZW1vdGUrcmVwbyt1c2UrZ2l0K2NoZWNrb3V0K2FuZCtzZXQrdXBzdHJlYW0uK1ZlcmlmeStkZXYrYnJhbmNoK2lzK29uK3JlbW90ZStyZXBvLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIya3BkaDYlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMkNyZWF0ZSthK2ZlYXR1cmUrYnJhbmNoK2FuZCtuYW1lK2l0K3RoZStmZWF0dXJlK3lvdSthcmUrd29ya2luZytvbi4lMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMjhza3lyJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJVc3VhbGx5K3RoZXJlK2FyZSttdWx0aXBsZStwYXJ0cyt0aGF0K21ha2UrdXArYStmZWF0dXJlK2luK2ErdGVhbStlbnZpcm9ubWVudCUyQytjcmVhdGUrdGhlK21haW4tZmVhdHVyZS1icmFuY2grYW5kK2JyYW5jaCtvZmYraW50bytwYXJ0cytvZit0aGUrZmVhdHVyZS4lMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMmcyMHp4JTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJFLmcuK01haW4tZmVhdHVyZS1icmFuY2grJTNEJTNFK3Nob3BwaW5nX2NhcnQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMjczdWl4JTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJTdWItZmVhdHVyZS1icmFuY2grJTNEJTNFK3Nob3BwaW5nX2NhcnRfbG9naWMlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMno0d3JwJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJTdWItZmVhdHVyZS1icmFuY2grJTNEJTNFK3Nob3BwaW5nX2NhcnRfc3R5bGluZyUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIyNHQzcnIlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMiUyOEluK3RoaXMrZXhhbXBsZStpdCt3b3VsZCtiZSthK2dvb2QraWRlYSt0bytoYXZlK3RoZStIVE1MK2luK3BsYWNlK2JlZm9yZSt0aGUrc3ViK2JyYW5jaGVzK2FyZStjcmVhdGVkJTI5JTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJ0Z25tZSUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyU2V0K3Vwc3RyZWFtK2FuZCtwdXNoK3lvdXIraW5pdGlhbCtjb21taXQuJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJ0M2U1ZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyRGV2ZWxvcCtiaXRzK29mK3RoZStmZWF0dXJlK2FuZCtjb21taXQrdGhlK2JpdHMlM0IrcHVzaCt0aGVtK3RvK3RoZStyZW1vdGUrcmVwb3NpdG9yeS4lMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMmVlMms3JTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJGaW5pc2grdGhlK2ZlYXR1cmUrYW5kK3B1c2grdGhlK2ZpbmFsK2NoYW5nZXMrdG8rdGhlK3JlbW90ZStyZXBvJTNCK3N1Ym1pdCttZXJnZStyZXF1ZXN0K29uK3JlbW90ZStyZXBvK2Zvcit0aGUrc3ViLWZlYXR1cmUtYnJhbmNoLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIyNmltN3glMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMk1lcmdlK3N1Yi1mZWF0dXJlLWJyYW5jaCtpbnRvK21haW4tZmVhdHVyZS1icmFuY2grb24rcmVtb3RlK3JlcG9zaXRvcnkuJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJqZ3ZiciUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyRGVsZXRlK3lvdXIrc3ViLWZlYXR1cmUtYnJhbmNoK2Zyb20rbG9jYWwrcmVwbythbmQrZnJvbStyZW1vdGUrcmVwby4lMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0eXBlJTIyJTNBKyUyMnVuc3R5bGVkJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIyaW5saW5lU3R5bGVSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIyZGVwdGglMjIlM0ErMCUwRCUwQSsrKysrKysrJTdEJTJDJTBEJTBBKysrKysrKyslN0IlMEQlMEErKysrKysrKysrKyslMjJlbnRpdHlSYW5nZXMlMjIlM0ErJTVCJTVEJTJDJTBEJTBBKysrKysrKysrKysrJTIya2V5JTIyJTNBKyUyMnBuOW45JTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydGV4dCUyMiUzQSslMjJnaXQrYnJhbmNoKy1kK2JyYW5jaC1uYW1lJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJvcmRlcmVkLWxpc3QtaXRlbSUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJlNzUzcCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyZ2l0K3B1c2grb3JpZ2luKyU1Q3UyMDE0ZGVsZXRlK2JyYW5jaC1uYW1lJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJvcmRlcmVkLWxpc3QtaXRlbSUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjJ1bHZ1eCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyQWxsK3BhcnRzK29mK3RoZSttYWluLWZlYXR1cmUtYnJhbmNoK2hhdmUrYmVlbitjb21wbGV0ZWQrdGhlbitzdWJtaXQrbWVyZ2UrcmVxdWVzdCt0bytkZXYrYnJhbmNoLitNZXJnZSt0aGUrbWFpbi1mZWF0dXJlLWJyYW5jaCtpbnRvK2RlditicmFuY2guJTIyJTJDJTBEJTBBKysrKysrKysrKysrJTIydHlwZSUyMiUzQSslMjJ1bnN0eWxlZCUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMmlubGluZVN0eWxlUmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmRlcHRoJTIyJTNBKzAlMEQlMEErKysrKysrKyU3RCUyQyUwRCUwQSsrKysrKysrJTdCJTBEJTBBKysrKysrKysrKysrJTIyZW50aXR5UmFuZ2VzJTIyJTNBKyU1QiU1RCUyQyUwRCUwQSsrKysrKysrKysrKyUyMmtleSUyMiUzQSslMjIzcjA2cSUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnRleHQlMjIlM0ErJTIyRGVsZXRlK3RoZSttYWluLWZlYXR1cmUtYnJhbmNoLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIyY3BzejclMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMkNoZWNrb3V0K2ludG8rZGV2K2JyYW5jaCtvbitsb2NhbCttYWNoaW5lK2FuZCtwdWxsK2Rvd24rY2hhbmdlcytmcm9tK3JlbW90ZStyZXBvK2RlditicmFuY2grdG8reW91citsb2NhbCtkZXYrYnJhbmNoLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMkMlMEQlMEErKysrKysrKyU3QiUwRCUwQSsrKysrKysrKysrKyUyMmVudGl0eVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJrZXklMjIlM0ErJTIybmw4OXMlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJ0ZXh0JTIyJTNBKyUyMlJpbnNlK2FuZCtyZXBlYXQuK0dvK2JhY2srdG8rdGhlK3N0ZXArd2hlcmUreW91K2JyYW5jaCtvZmYrdGhlK2RlditicmFuY2graW50byt5b3VyK2ZlYXR1cmUrYnJhbmNoLiUyMiUyQyUwRCUwQSsrKysrKysrKysrKyUyMnR5cGUlMjIlM0ErJTIydW5zdHlsZWQlMjIlMkMlMEQlMEErKysrKysrKysrKyslMjJpbmxpbmVTdHlsZVJhbmdlcyUyMiUzQSslNUIlNUQlMkMlMEQlMEErKysrKysrKysrKyslMjJkZXB0aCUyMiUzQSswJTBEJTBBKysrKysrKyslN0QlMEQlMEErKysrJTVEJTJDJTBEJTBBKysrKyUyMmVudGl0eU1hcCUyMiUzQSslN0IlN0QlMEQlMEElN0QiLDE1NTA2MDc3OTEuMDEzNjM5Ml19	2019-03-05 20:23:11.029737+00
\.


--
-- Data for Name: home_homepage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.home_homepage (page_ptr_id, hero_text, hero_title, body, promo_title, promo_text, featured_section_1_title, featured_section_2_title, featured_section_1_id, featured_section_2_id, promo_image_id, resume_id) FROM stdin;
3	Andrew K. Telleria	Full Stack Developer	[{"value": "<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>", "type": "paragraph_block", "id": "38a60420-fd24-4c7d-a3a9-83e934a9951f"}]	Who am I?	<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS. Visit my <a href="http://github.com/andrewtelleria">GitHub</a> and checkout what I am working on</p>	Projects and Skills	Blog	\N	\N	15	1
\.


--
-- Data for Name: home_homepageimagegallery; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.home_homepageimagegallery (id, sort_order, caption, logo, image_id, page_id) FROM stdin;
\.


--
-- Name: home_homepageimagegallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.home_homepageimagegallery_id_seq', 1, false);


--
-- Data for Name: home_people; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.home_people (id, first_name, last_name, job_title, about, image_id) FROM stdin;
1	Andrew	Telleria	Full Stack Web Developer	Full Stack Web Developer out of Portland, Oregon. I primarily code in the backend using Python but I like to dabble in the frontend and get my hands dirty with CSS.	\N
\.


--
-- Name: home_people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.home_people_id_seq', 1, true);


--
-- Data for Name: home_skills; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.home_skills (id, sort_order, skill, percentage, page_id) FROM stdin;
1	0	Python	60	3
2	1	Django	55	3
3	2	JavaScript	50	3
4	3	HTML	50	3
5	4	CSS	40	3
6	5	Java	40	3
7	6	AWS	35	3
8	7	Angular	30	3
9	8	Android	30	3
\.


--
-- Name: home_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.home_skills_id_seq', 9, true);


--
-- Data for Name: home_standardpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.home_standardpage (page_ptr_id, introduction, body, image_id) FROM stdin;
8	About Page	[{"value": "<p>Hello, thank you visiting my page. Here I will tell you a little about myself and how I wound up where I am today. I started my coding journey when I attended a coding bootcamp in Portland, Oregon named Epicodus. Prior to Epicodus I graduated from the University of Oregon with an Economics degree. The jobs that were available for my degree were in financial industry and that wasn&#x27;t an industry I wanted to be a part of. So out of college I started working retail until I honed in on what I wanted to do as a career. I needed a career that would feed my curiosity and my creativity. Computers were always something that seemed mysterious to me and it was something that I wanted to understand more considering everything in our modern world has been touched by a computer in one way or another. I did a couple Google searches and found out that there are code schools in the Portland area that cost significantly less than going back to under grad to get a Computer Science degree. I finally came down to Epicodus since it was a cost efficient coding school and it was 40 hours a week of intense programming. My only problem with Epicodus was that they didn&#x27;t really touch on the basics of Computer Science which I have taught myself some of the basics through free sources on the internet. What I took out of my experience at Epicodus was how to learn new technologies at a fast pace. What I enjoyed learning most was JavaScript. I really liked jQuery and the JavaScript frameworks Ember.js and Angular. After Epicodus is when I taught myself Python. I got a job at a small tech company doing some basic wordpress installations and SEO work. I didn&#x27;t feel that that my skills were being used and I wanted to explore other options. </p>", "id": "09574a6f-c77c-43c4-a8ae-bcf908a73b3f", "type": "paragraph_block"}]	\N
\.


--
-- Data for Name: projects_projectindexpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.projects_projectindexpage (page_ptr_id, intro) FROM stdin;
4	<p>Here are some of my projects and if you see something you like please send me an email. I don&#x27;t mind talking about about my work.</p>
\.


--
-- Data for Name: projects_projectpage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.projects_projectpage (page_ptr_id, feature, project_url, github, date, intro, body, image_id) FROM stdin;
5	1	\N	https://github.com/AndrewTelleria/phi	2018-07-12	This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.	[{"value": "<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>", "type": "paragraph", "id": "3726733a-4548-494a-aa0e-71ee3b5abd2c"}]	14
\.


--
-- Data for Name: projects_projectpagegalleryimage; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.projects_projectpagegalleryimage (id, sort_order, caption, image_id, page_id) FROM stdin;
2	1	Homepage Services	6	5
3	2	Homepage About	5	5
5	4	Homepage Photo Gallery and Footer	10	5
7	6	Blog Page	9	5
\.


--
-- Name: projects_projectpagegalleryimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.projects_projectpagegalleryimage_id_seq', 8, true);


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.taggit_tag (id, name, slug) FROM stdin;
1	wagtail	wagtail
2	django	django
3	python	python
4	web development	web-development
\.


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.taggit_tag_id_seq', 4, true);


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
1	16	2	1
2	16	2	2
\.


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.taggit_taggeditem_id_seq', 2, true);


--
-- Data for Name: wagtailcore_collection; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_collection (id, path, depth, numchild, name) FROM stdin;
1	0001	1	0	Root
\.


--
-- Name: wagtailcore_collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_collection_id_seq', 1, true);


--
-- Data for Name: wagtailcore_collectionviewrestriction; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_collectionviewrestriction (id, restriction_type, password, collection_id) FROM stdin;
\.


--
-- Data for Name: wagtailcore_collectionviewrestriction_groups; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_collectionviewrestriction_groups (id, collectionviewrestriction_id, group_id) FROM stdin;
\.


--
-- Name: wagtailcore_collectionviewrestriction_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_collectionviewrestriction_groups_id_seq', 1, false);


--
-- Name: wagtailcore_collectionviewrestriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_collectionviewrestriction_id_seq', 1, false);


--
-- Data for Name: wagtailcore_groupcollectionpermission; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_groupcollectionpermission (id, collection_id, group_id, permission_id) FROM stdin;
1	1	1	1
2	1	2	1
3	1	1	2
4	1	2	2
5	1	1	4
6	1	2	4
7	1	1	5
8	1	2	5
\.


--
-- Name: wagtailcore_groupcollectionpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_groupcollectionpermission_id_seq', 8, true);


--
-- Data for Name: wagtailcore_grouppagepermission; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_grouppagepermission (id, permission_type, group_id, page_id) FROM stdin;
1	add	1	1
2	edit	1	1
3	publish	1	1
4	add	2	1
5	edit	2	1
6	lock	1	1
\.


--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_grouppagepermission_id_seq', 6, true);


--
-- Data for Name: wagtailcore_page; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_page (id, path, depth, numchild, title, slug, live, has_unpublished_changes, url_path, seo_title, show_in_menus, search_description, go_live_at, expire_at, expired, content_type_id, owner_id, locked, latest_revision_created_at, first_published_at, live_revision_id, last_published_at, draft_title) FROM stdin;
9	0001000100020001	4	0	A CMS that makes sense	cms-makes-sense	f	t	/home/blog/cms-makes-sense/		f		\N	\N	f	9	1	f	2018-11-01 20:28:33.578124+00	\N	\N	\N	A CMS that makes sense
3	00010001	2	3	Home	home	t	f	/home/		f		\N	\N	f	14	1	f	2018-11-07 17:57:22.439771+00	2018-08-17 00:45:28.074055+00	37	2018-11-07 17:57:22.480028+00	Home
1	0001	1	1	Root	root	t	f	/		f		\N	\N	f	1	\N	f	\N	\N	\N	\N	Root
6	000100010002	3	2	Blog	blog	t	f	/home/blog/		f		\N	\N	f	8	1	f	2019-02-19 20:14:30.608271+00	2018-08-23 00:36:21.02164+00	38	2019-02-19 20:14:30.641518+00	Blog
10	0001000100020002	4	0	Git Workflow	git-workflow	f	t	/home/blog/git-workflow/		f		\N	\N	f	9	1	f	2019-02-19 20:23:05.653047+00	\N	\N	\N	Git Workflow
4	000100010001	3	1	Projects	projects	t	f	/home/projects/		f		\N	\N	f	16	1	f	2018-08-17 16:23:33.975356+00	2018-08-17 16:23:33.990483+00	2	2018-08-17 16:23:33.990483+00	Projects
8	000100010003	3	0	About	about	t	f	/home/about/		f		\N	\N	f	15	1	f	2018-09-10 16:22:50.695496+00	2018-09-06 23:07:10.843578+00	23	2018-09-10 16:22:50.714036+00	About
5	0001000100010001	4	0	Pup House Inn	pup-house-inn	t	f	/home/projects/pup-house-inn/		f		\N	\N	f	17	1	f	2018-10-25 22:52:55.650734+00	2018-08-17 16:34:14.364361+00	27	2018-10-25 22:52:55.681842+00	Pup House Inn
\.


--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_page_id_seq', 10, true);


--
-- Data for Name: wagtailcore_pagerevision; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_pagerevision (id, submitted_for_moderation, created_at, content_json, approved_go_live_at, page_id, user_id) FROM stdin;
2	f	2018-08-17 16:23:33.975356+00	{"go_live_at": null, "numchild": 0, "draft_title": "Projects", "last_published_at": null, "seo_title": "", "title": "Projects", "live": true, "locked": false, "intro": "<p>Here are some of my projects and if you see something you like please send me an email. I don&#x27;t mind talking about about my work.</p>", "show_in_menus": false, "expired": false, "has_unpublished_changes": false, "depth": 3, "url_path": "/home/projects/", "path": "000100010001", "expire_at": null, "search_description": "", "owner": 1, "live_revision": null, "slug": "projects", "content_type": 16, "pk": 4, "first_published_at": null, "latest_revision_created_at": null}	\N	4	1
13	f	2018-09-06 23:07:43.581604+00	{"draft_title": "Aout", "path": "000100010003", "introduction": "About Page", "depth": 3, "slug": "aout", "owner": 1, "latest_revision_created_at": "2018-09-06T23:07:10.826Z", "pk": 8, "expired": false, "image": null, "content_type": 15, "search_description": "", "live": true, "title": "About", "show_in_menus": false, "live_revision": 12, "seo_title": "", "numchild": 0, "url_path": "/home/aout/", "first_published_at": "2018-09-06T23:07:10.843Z", "go_live_at": null, "expire_at": null, "locked": false, "has_unpublished_changes": false, "body": "[{\\"type\\": \\"paragraph_block\\", \\"id\\": \\"09574a6f-c77c-43c4-a8ae-bcf908a73b3f\\", \\"value\\": \\"<p>Write some things.</p>\\"}]", "last_published_at": "2018-09-06T23:07:10.843Z"}	\N	8	1
14	f	2018-09-06 23:07:51.983728+00	{"draft_title": "About", "path": "000100010003", "introduction": "About Page", "depth": 3, "slug": "about", "owner": 1, "latest_revision_created_at": "2018-09-06T23:07:43.581Z", "pk": 8, "expired": false, "image": null, "content_type": 15, "search_description": "", "live": true, "title": "About", "show_in_menus": false, "live_revision": 13, "seo_title": "", "numchild": 0, "url_path": "/home/aout/", "first_published_at": "2018-09-06T23:07:10.843Z", "go_live_at": null, "expire_at": null, "locked": false, "has_unpublished_changes": false, "body": "[{\\"type\\": \\"paragraph_block\\", \\"id\\": \\"09574a6f-c77c-43c4-a8ae-bcf908a73b3f\\", \\"value\\": \\"<p>Write some things.</p>\\"}]", "last_published_at": "2018-09-06T23:07:43.600Z"}	\N	8	1
4	f	2018-08-17 16:37:03.617802+00	{"go_live_at": null, "numchild": 0, "draft_title": "Pup House Inn", "body": "[{\\"type\\": \\"paragraph\\", \\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "last_published_at": "2018-08-17T16:34:14.364Z", "seo_title": "", "title": "Pup House Inn", "live": true, "locked": false, "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "show_in_menus": false, "expired": false, "project_url": "http://www.pup-house.com", "date": "2018-07-12", "image": 1, "has_unpublished_changes": false, "depth": 4, "url_path": "/home/projects/pup-house-inn/", "path": "0001000100010001", "expire_at": null, "search_description": "", "feature": 1, "gallery_images": [], "owner": 1, "live_revision": 3, "slug": "pup-house-inn", "github": "https://github.com/AndrewTelleria/phi", "content_type": 17, "pk": 5, "first_published_at": "2018-08-17T16:34:14.364Z", "latest_revision_created_at": "2018-08-17T16:34:14.348Z"}	\N	5	1
1	f	2018-08-17 00:45:28.057246+00	{"featured_section_1": null, "pk": 3, "content_type": 14, "depth": 2, "skill_7_percentage": null, "url_path": "/home/", "skill_6_percentage": null, "promo_title": null, "gallery_images": [], "resume": null, "hero_title": "Full Stack Developer", "expire_at": null, "hero_text": "Andrew K. Telleria", "skill_4": null, "slug": "home", "skill_1_percentage": null, "skill_5": null, "live_revision": null, "path": "00010001", "show_in_menus": false, "skill_6": null, "skill_8_percentage": null, "first_published_at": null, "featured_section_1_title": null, "live": true, "last_published_at": null, "numchild": 0, "promo_text": "<p></p>", "has_unpublished_changes": false, "image": null, "search_description": "", "seo_title": "", "skill_1": null, "skill_3_percentage": null, "owner": 1, "skill_5_percentage": null, "promo_image": null, "featured_section_2": null, "skill_2_percentage": null, "skill_2": null, "body": "[{\\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "skill_9_percentage": null, "locked": false, "go_live_at": null, "latest_revision_created_at": null, "skill_9": null, "skill_3": null, "skill_4_percentage": null, "draft_title": "Home", "featured_section_2_title": null, "title": "Home", "skill_7": null, "expired": false, "logo_image": null, "skill_8": null}	\N	3	1
22	f	2018-09-10 15:51:25.048153+00	{"featured_section_1_title": "Projects and Skills", "skill_9": "Java", "depth": 2, "featured_section_2": null, "skill_1": "Python", "skill_3": "JavaScript", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS.</p>", "logo_image": null, "path": "00010001", "resume": 1, "gallery_images": [], "seo_title": "", "has_unpublished_changes": false, "last_published_at": "2018-09-10T15:36:17.055Z", "skill_5": "HTML", "show_in_menus": false, "skill_7": "Angular", "skill_8_percentage": 30, "content_type": 14, "promo_title": "Who am I?", "skill_4": "CSS", "skill_6": "AWS", "skill_6_percentage": 40, "live_revision": 21, "locked": false, "hero_title": "Full Stack Developer", "skill_4_percentage": 50, "skill_7_percentage": 30, "title": "Home", "latest_revision_created_at": "2018-09-10T15:36:17.032Z", "promo_image": 15, "skill_1_percentage": 70, "skill_2_percentage": 60, "expire_at": null, "featured_section_1": null, "skill_3_percentage": 50, "url_path": "/home/", "slug": "home", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "skill_9_percentage": 30, "numchild": 3, "pk": 3, "expired": false, "draft_title": "Home", "image": null, "owner": 1, "skill_5_percentage": 60, "go_live_at": null, "skill_2": "Django", "search_description": "", "first_published_at": "2018-08-17T00:45:28.074Z", "hero_text": "Andrew K. Telleria", "skill_8": "Ember.js", "live": true, "featured_section_2_title": "Blog"}	\N	3	1
29	f	2018-11-01 20:02:37.0468+00	{"has_unpublished_changes": false, "url_path": "/home/blog/cms-makes-sense/", "image": 16, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": 1, "tag": 1, "content_object": 9}, {"pk": 2, "tag": 2, "content_object": 9}, {"pk": 3, "tag": 3, "content_object": 9}, {"pk": 4, "tag": 4, "content_object": 9}], "latest_revision_created_at": null, "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django is you write views and your urls pick which view to execute. </p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
5	f	2018-08-17 16:45:39.641059+00	{"go_live_at": null, "numchild": 0, "draft_title": "Pup House Inn", "body": "[{\\"type\\": \\"paragraph\\", \\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "last_published_at": "2018-08-17T16:37:03.638Z", "seo_title": "", "title": "Pup House Inn", "live": true, "locked": false, "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "show_in_menus": false, "expired": false, "project_url": "http://www.pup-house.com", "date": "2018-07-12", "image": 2, "has_unpublished_changes": false, "depth": 4, "url_path": "/home/projects/pup-house-inn/", "path": "0001000100010001", "expire_at": null, "search_description": "", "feature": 1, "gallery_images": [], "owner": 1, "live_revision": 4, "slug": "pup-house-inn", "github": "https://github.com/AndrewTelleria/phi", "content_type": 17, "pk": 5, "first_published_at": "2018-08-17T16:34:14.364Z", "latest_revision_created_at": "2018-08-17T16:37:03.617Z"}	\N	5	1
30	f	2018-11-01 20:05:27.248557+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 17, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:02:37.046Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django is you write views and your urls pick which view to execute.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
7	f	2018-08-23 00:33:20.955478+00	{"body": "[{\\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "seo_title": "", "resume": null, "skill_5": "HTML", "live": true, "draft_title": "Home", "promo_image": 12, "hero_text": "Andrew K. Telleria", "skill_4": "CSS", "expire_at": null, "image": null, "pk": 3, "skill_4_percentage": 50, "last_published_at": "2018-08-17T00:45:28.074Z", "go_live_at": null, "skill_1": "Python", "content_type": 14, "featured_section_2": null, "first_published_at": "2018-08-17T00:45:28.074Z", "skill_1_percentage": 70, "skill_2": "Django", "logo_image": null, "skill_3": "JavaScript", "skill_6": "AWS", "promo_text": "<p>I am a full stack web developer located in Portland, Oregon.</p>", "skill_8": "Ember.js", "gallery_images": [], "promo_title": "Who am I?", "latest_revision_created_at": "2018-08-17T00:45:28.057Z", "expired": false, "hero_title": "Full Stack Developer", "show_in_menus": false, "skill_3_percentage": 50, "numchild": 1, "skill_2_percentage": 60, "live_revision": 1, "skill_9_percentage": 30, "skill_6_percentage": 40, "has_unpublished_changes": false, "skill_7_percentage": 30, "featured_section_2_title": null, "locked": false, "depth": 2, "url_path": "/home/", "skill_8_percentage": 30, "path": "00010001", "search_description": "", "skill_9": "Java", "skill_7": "Angular", "owner": 1, "skill_5_percentage": 60, "title": "Home", "slug": "home", "featured_section_1": null, "featured_section_1_title": null}	\N	3	1
31	f	2018-11-01 20:09:38.279874+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 18, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:05:27.248Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django is you write views and your urls pick which view to execute.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
9	f	2018-08-23 00:36:21.006298+00	{"expired": false, "seo_title": "", "numchild": 0, "live_revision": null, "show_in_menus": false, "has_unpublished_changes": false, "draft_title": "Blog", "depth": 3, "expire_at": null, "url_path": "/home/blog/", "last_published_at": null, "path": "000100010002", "search_description": "", "go_live_at": null, "locked": false, "live": true, "first_published_at": null, "owner": 1, "content_type": 8, "title": "Blog", "slug": "blog", "pk": 6, "intro": "<p>Here are some topics that I found interesting.</p>", "latest_revision_created_at": null}	\N	6	1
3	f	2018-08-17 16:34:14.348854+00	{"go_live_at": null, "numchild": 0, "draft_title": "Pup House Inn", "body": "[{\\"type\\": \\"paragraph\\", \\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "last_published_at": null, "seo_title": "", "title": "Pup House Inn", "live": true, "locked": false, "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "show_in_menus": false, "expired": false, "project_url": "http://www.pup-house.com", "date": "2018-07-12", "image": null, "has_unpublished_changes": false, "depth": 4, "url_path": "/home/projects/pup-house-inn/", "path": "0001000100010001", "expire_at": null, "search_description": "", "feature": 1, "gallery_images": [], "owner": 1, "live_revision": null, "slug": "pup-house-inn", "github": "https://github.com/AndrewTelleria/phi", "content_type": 17, "pk": 5, "first_published_at": null, "latest_revision_created_at": null}	\N	5	1
24	f	2018-09-10 16:31:39.421941+00	{"featured_section_1_title": "Projects and Skills", "skill_9": "Java", "depth": 2, "featured_section_2": null, "skill_1": "Python", "skill_3": "JavaScript", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS.</p>", "logo_image": null, "path": "00010001", "resume": 1, "gallery_images": [], "seo_title": "", "has_unpublished_changes": false, "last_published_at": "2018-09-10T15:51:25.087Z", "skill_5": "HTML", "show_in_menus": false, "skill_7": "PostgreSQL", "skill_8_percentage": 30, "content_type": 14, "promo_title": "Who am I?", "skill_4": "CSS", "skill_6": "AWS", "skill_6_percentage": 40, "live_revision": 22, "locked": false, "hero_title": "Full Stack Developer", "skill_4_percentage": 50, "skill_7_percentage": 40, "title": "Home", "latest_revision_created_at": "2018-09-10T15:51:25.048Z", "promo_image": 15, "skill_1_percentage": 70, "skill_2_percentage": 60, "expire_at": null, "featured_section_1": null, "skill_3_percentage": 50, "url_path": "/home/", "slug": "home", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "skill_9_percentage": 30, "numchild": 3, "pk": 3, "expired": false, "draft_title": "Home", "image": null, "owner": 1, "skill_5_percentage": 50, "go_live_at": null, "skill_2": "Django", "search_description": "", "first_published_at": "2018-08-17T00:45:28.074Z", "hero_text": "Andrew K. Telleria", "skill_8": "Ember.js", "live": true, "featured_section_2_title": "Blog"}	\N	3	1
32	f	2018-11-01 20:09:52.930954+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 18, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:09:38.279Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django is you write views and your urls pick which view to execute.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
12	f	2018-09-06 23:07:10.826699+00	{"draft_title": "Aout", "path": "000100010003", "introduction": "About Page", "depth": 3, "slug": "aout", "owner": 1, "latest_revision_created_at": null, "pk": 8, "expired": false, "image": null, "content_type": 15, "search_description": "", "live": true, "title": "Aout", "show_in_menus": false, "live_revision": null, "seo_title": "", "numchild": 0, "url_path": "/home/aout/", "first_published_at": null, "go_live_at": null, "expire_at": null, "locked": false, "has_unpublished_changes": false, "body": "[{\\"type\\": \\"paragraph_block\\", \\"id\\": \\"09574a6f-c77c-43c4-a8ae-bcf908a73b3f\\", \\"value\\": \\"<p>Write some things.</p>\\"}]", "last_published_at": null}	\N	8	1
33	f	2018-11-01 20:12:54.012349+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 19, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:09:52.930Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p>Wagtail is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django, you write views and your urls pick which view to run.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
34	f	2018-11-01 20:24:01.475154+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 19, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:12:54.012Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p><a href=\\\\\\"https://wagtail.io/\\\\\\">Wagtail</a> is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django, you write views and your urls pick which view to run.</p><p></p><p>A cool feature of Wagtail is that it can work along with you Django application. From their website &quot;it will play nicely with everything in your tech stack&quot;. It can also be used as a micro-service with its built in API so you can work with your front end framework of choice. I truly believe it&#x27;s built for everyone that will encounter it from the developer to the content editor. Its open source and amazing. As you can tell I am excited about this technology.</p><p>```</p><p>pip install wagtail</p><p>```</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
8	f	2018-08-23 00:34:03.134104+00	{"body": "[{\\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "seo_title": "", "resume": null, "skill_5": "HTML", "live": true, "draft_title": "Home", "promo_image": 12, "hero_text": "Andrew K. Telleria", "skill_4": "CSS", "expire_at": null, "image": null, "pk": 3, "skill_4_percentage": 50, "last_published_at": "2018-08-23T00:33:20.976Z", "go_live_at": null, "skill_1": "Python", "content_type": 14, "featured_section_2": null, "first_published_at": "2018-08-17T00:45:28.074Z", "skill_1_percentage": 70, "skill_2": "Django", "logo_image": null, "skill_3": "JavaScript", "skill_6": "AWS", "promo_text": "<p>I am a full stack web developer located in Portland, Oregon.</p>", "skill_8": "Ember.js", "gallery_images": [], "promo_title": "Who am I?", "latest_revision_created_at": "2018-08-23T00:33:20.955Z", "expired": false, "hero_title": "Full Stack Developer", "show_in_menus": false, "skill_3_percentage": 50, "numchild": 1, "skill_2_percentage": 60, "live_revision": 7, "skill_9_percentage": 30, "skill_6_percentage": 40, "has_unpublished_changes": false, "skill_7_percentage": 30, "featured_section_2_title": "Blog", "locked": false, "depth": 2, "url_path": "/home/", "skill_8_percentage": 30, "path": "00010001", "search_description": "", "skill_9": "Java", "skill_7": "Angular", "owner": 1, "skill_5_percentage": 60, "title": "Home", "slug": "home", "featured_section_1": null, "featured_section_1_title": "Projects and Skills"}	\N	3	1
16	f	2018-09-07 03:15:17.279755+00	{"skill_7_percentage": 30, "live_revision": 8, "resume": 1, "skill_9_percentage": 30, "featured_section_2": null, "last_published_at": "2018-08-23T00:34:03.154Z", "image": null, "promo_text": "<p>I am a full stack web developer located in Portland, Oregon.</p>", "first_published_at": "2018-08-17T00:45:28.074Z", "url_path": "/home/", "skill_3": "JavaScript", "skill_3_percentage": 50, "expire_at": null, "skill_4": "CSS", "gallery_images": [], "promo_image": null, "live": true, "draft_title": "Home", "search_description": "", "skill_2_percentage": 60, "seo_title": "", "skill_6_percentage": 40, "content_type": 14, "has_unpublished_changes": false, "expired": false, "pk": 3, "go_live_at": null, "promo_title": "Who am I?", "depth": 2, "skill_8_percentage": 30, "skill_7": "Angular", "locked": false, "body": "[{\\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"type\\": \\"paragraph_block\\"}]", "skill_1_percentage": 70, "title": "Home", "path": "00010001", "skill_5_percentage": 60, "hero_title": "Full Stack Developer", "owner": 1, "logo_image": null, "skill_8": "Ember.js", "numchild": 3, "featured_section_2_title": "Blog", "skill_4_percentage": 50, "show_in_menus": false, "featured_section_1_title": "Projects and Skills", "skill_9": "Java", "hero_text": "Andrew K. Telleria", "slug": "home", "skill_1": "Python", "featured_section_1": null, "skill_2": "Django", "skill_5": "HTML", "skill_6": "AWS", "latest_revision_created_at": "2018-08-23T00:34:03.134Z"}	\N	3	1
35	f	2018-11-01 20:24:04.597666+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 19, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:24:01.475Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p><a href=\\\\\\"https://wagtail.io/\\\\\\">Wagtail</a> is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django, you write views and your urls pick which view to run.</p><p></p><p>A cool feature of Wagtail is that it can work along with you Django application. From their website &quot;it will play nicely with everything in your tech stack&quot;. It can also be used as a micro-service with its built in API so you can work with your front end framework of choice. I truly believe it&#x27;s built for everyone that will encounter it from the developer to the content editor. Its open source and amazing. As you can tell I am excited about this technology.</p><p>```</p><p>pip install wagtail</p><p>```</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
17	f	2018-09-07 03:19:08.05072+00	{"skill_7_percentage": 30, "live_revision": 16, "resume": 1, "skill_9_percentage": 30, "featured_section_2": 6, "last_published_at": "2018-09-07T03:15:17.301Z", "image": null, "promo_text": "<p>I am a full stack web developer located in Portland, Oregon.</p>", "first_published_at": "2018-08-17T00:45:28.074Z", "url_path": "/home/", "skill_3": "JavaScript", "skill_3_percentage": 50, "expire_at": null, "skill_4": "CSS", "gallery_images": [], "promo_image": null, "live": true, "draft_title": "Home", "search_description": "", "skill_2_percentage": 60, "seo_title": "", "skill_6_percentage": 40, "content_type": 14, "has_unpublished_changes": false, "expired": false, "pk": 3, "go_live_at": null, "promo_title": "Who am I?", "depth": 2, "skill_8_percentage": 30, "skill_7": "Angular", "locked": false, "body": "[{\\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"type\\": \\"paragraph_block\\"}]", "skill_1_percentage": 70, "title": "Home", "path": "00010001", "skill_5_percentage": 60, "hero_title": "Full Stack Developer", "owner": 1, "logo_image": null, "skill_8": "Ember.js", "numchild": 3, "featured_section_2_title": "Blog", "skill_4_percentage": 50, "show_in_menus": false, "featured_section_1_title": "Projects and Skills", "skill_9": "Java", "hero_text": "Andrew K. Telleria", "slug": "home", "skill_1": "Python", "featured_section_1": 4, "skill_2": "Django", "skill_5": "HTML", "skill_6": "AWS", "latest_revision_created_at": "2018-09-07T03:15:17.279Z"}	\N	3	1
36	f	2018-11-01 20:28:33.578124+00	{"has_unpublished_changes": true, "url_path": "/home/blog/cms-makes-sense/", "image": 19, "go_live_at": null, "feature": 1, "show_in_menus": false, "author": null, "live": false, "seo_title": "", "date": "2018-11-01", "content_type": 9, "tagged_items": [{"pk": null, "tag": 1, "content_object": 9}, {"pk": null, "tag": 2, "content_object": 9}, {"pk": null, "tag": 3, "content_object": 9}, {"pk": null, "tag": 4, "content_object": 9}], "latest_revision_created_at": "2018-11-01T20:24:04.597Z", "live_revision": null, "title": "A CMS that makes sense", "last_published_at": null, "path": "0001000100020001", "search_description": "", "expire_at": null, "body": "[{\\"value\\": \\"<p><a href=\\\\\\"https://wagtail.io/\\\\\\">Wagtail</a> is an amazing CMS that is built on top of Django. Coming from a Python background I was looking for a CMS that was built with Python. I was talking to a friend of mine who is also a developer told me to look into using Wagtail and he had worked with it at work. I did my due diligence and investigated what Wagtail was all about. I got into their docs and went through their tutorial on how to build a blog. Immediately I could tell that I was going to enjoy working with Wagtail. A couple things were throwing me off though and that was the urls and views. I did not have to write urls or views. That was weird to me because that is what you do with Django, you write views and your urls pick which view to run.</p><p></p><p>A cool feature of Wagtail is that it can work along with you Django application. From their website &quot;it will play nicely with everything in your tech stack&quot;. It can also be used as a micro-service with its built in API so you can work with your front end framework of choice. I truly believe it&#x27;s built for everyone that will encounter it from the developer to the content editor. Its open source and amazing. As you can tell I am excited about this technology.</p><p></p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"57be7b09-ee7c-4aae-8f98-62bebfd1d9c1\\"}]", "numchild": 0, "draft_title": "A CMS that makes sense", "pk": 9, "slug": "cms-makes-sense", "intro": "My experience working with Wagtail has been a lot of fun. I enjoy working with Python and Wagtail's CMS is fun to work with too.", "expired": false, "depth": 4, "first_published_at": null, "owner": 1, "locked": false}	\N	9	1
28	f	2018-10-25 23:07:26.43125+00	{"featured_section_1_title": "Projects and Skills", "has_unpublished_changes": false, "url_path": "/home/", "featured_section_2": null, "go_live_at": null, "show_in_menus": false, "featured_section_2_title": "Blog", "live": true, "gallery_images": [], "seo_title": "", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS. Visit my <a href=\\"http://github.com/andrewtelleria\\">GitHub</a> and checkout what I am working on</p>", "featured_section_1": null, "content_type": 14, "latest_revision_created_at": "2018-10-25T22:41:49.160Z", "live_revision": 25, "resume": 1, "title": "Home", "last_published_at": "2018-10-25T22:41:49.200Z", "hero_title": "Full Stack Developer", "path": "00010001", "search_description": "", "expire_at": null, "skills": [{"pk": 1, "sort_order": 0, "page": 3, "skill": "Python", "percentage": 60}, {"pk": 2, "sort_order": 1, "page": 3, "skill": "Django", "percentage": 55}, {"pk": 3, "sort_order": 2, "page": 3, "skill": "JavaScript", "percentage": 50}, {"pk": 4, "sort_order": 3, "page": 3, "skill": "HTML", "percentage": 50}, {"pk": 5, "sort_order": 4, "page": 3, "skill": "CSS", "percentage": 40}, {"pk": 6, "sort_order": 5, "page": 3, "skill": "Java", "percentage": 35}, {"pk": 7, "sort_order": 6, "page": 3, "skill": "AWS", "percentage": 35}, {"pk": 8, "sort_order": 7, "page": 3, "skill": "Angular", "percentage": 30}, {"pk": 9, "sort_order": 8, "page": 3, "skill": "Android", "percentage": 30}], "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"type\\": \\"paragraph_block\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\"}]", "numchild": 3, "draft_title": "Home", "hero_text": "Andrew K. Telleria", "pk": 3, "slug": "home", "promo_title": "Who am I?", "promo_image": 15, "expired": false, "depth": 2, "first_published_at": "2018-08-17T00:45:28.074Z", "owner": 1, "locked": false}	\N	3	1
37	f	2018-11-07 17:57:22.439771+00	{"featured_section_1_title": "Projects and Skills", "has_unpublished_changes": false, "url_path": "/home/", "featured_section_2": null, "go_live_at": null, "show_in_menus": false, "featured_section_2_title": "Blog", "live": true, "gallery_images": [], "seo_title": "", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS. Visit my <a href=\\"http://github.com/andrewtelleria\\">GitHub</a> and checkout what I am working on</p>", "featured_section_1": null, "content_type": 14, "latest_revision_created_at": "2018-10-25T23:07:26.431Z", "live_revision": 28, "resume": 1, "title": "Home", "last_published_at": "2018-10-25T23:07:26.468Z", "hero_title": "Full Stack Developer", "path": "00010001", "search_description": "", "expire_at": null, "skills": [{"pk": 1, "sort_order": 0, "page": 3, "skill": "Python", "percentage": 60}, {"pk": 2, "sort_order": 1, "page": 3, "skill": "Django", "percentage": 55}, {"pk": 3, "sort_order": 2, "page": 3, "skill": "JavaScript", "percentage": 50}, {"pk": 4, "sort_order": 3, "page": 3, "skill": "HTML", "percentage": 50}, {"pk": 5, "sort_order": 4, "page": 3, "skill": "CSS", "percentage": 40}, {"pk": 6, "sort_order": 5, "page": 3, "skill": "Java", "percentage": 40}, {"pk": 7, "sort_order": 6, "page": 3, "skill": "AWS", "percentage": 35}, {"pk": 8, "sort_order": 7, "page": 3, "skill": "Angular", "percentage": 30}, {"pk": 9, "sort_order": 8, "page": 3, "skill": "Android", "percentage": 30}], "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"type\\": \\"paragraph_block\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\"}]", "numchild": 3, "draft_title": "Home", "hero_text": "Andrew K. Telleria", "pk": 3, "slug": "home", "promo_title": "Who am I?", "promo_image": 15, "expired": false, "depth": 2, "first_published_at": "2018-08-17T00:45:28.074Z", "owner": 1, "locked": false}	\N	3	1
21	f	2018-09-10 15:36:17.032603+00	{"skill_7_percentage": 30, "featured_section_2": null, "image": null, "featured_section_2_title": "Blog", "hero_title": "Full Stack Developer", "featured_section_1": null, "draft_title": "Home", "path": "00010001", "skill_3_percentage": 50, "locked": false, "skill_8_percentage": 30, "skill_7": "Angular", "skill_8": "Ember.js", "go_live_at": null, "owner": 1, "skill_5": "HTML", "expire_at": null, "featured_section_1_title": "Projects and Skills", "skill_2_percentage": 60, "has_unpublished_changes": false, "promo_title": "Who am I?", "seo_title": "", "skill_9_percentage": 30, "skill_6": "AWS", "live_revision": 20, "expired": false, "title": "Home", "latest_revision_created_at": "2018-09-10T15:35:52.271Z", "depth": 2, "gallery_images": [], "url_path": "/home/", "first_published_at": "2018-08-17T00:45:28.074Z", "resume": 1, "show_in_menus": false, "skill_9": "Java", "skill_2": "Django", "skill_6_percentage": 40, "numchild": 3, "skill_4_percentage": 50, "promo_image": 15, "slug": "home", "skill_1": "Python", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "content_type": 14, "pk": 3, "skill_1_percentage": 70, "logo_image": null, "skill_3": "JavaScript", "live": true, "hero_text": "Andrew K. Telleria", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I grew up in Salem, got my under grad at the University of Oregon, and now I reside in Portland. I attended Epicodus coding bootcamp to pursue a new career in tech and I have taught myself Python. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS.</p>", "last_published_at": "2018-09-10T15:35:52.292Z", "search_description": "", "skill_5_percentage": 60, "skill_4": "CSS"}	\N	3	1
18	f	2018-09-07 03:21:24.026279+00	{"skill_7_percentage": 30, "live_revision": 17, "resume": 1, "skill_9_percentage": 30, "featured_section_2": null, "last_published_at": "2018-09-07T03:19:08.076Z", "image": null, "promo_text": "<p>I am a full stack web developer located in Portland, Oregon.</p>", "first_published_at": "2018-08-17T00:45:28.074Z", "url_path": "/home/", "skill_3": "JavaScript", "skill_3_percentage": 50, "expire_at": null, "skill_4": "CSS", "gallery_images": [], "promo_image": null, "live": true, "draft_title": "Home", "search_description": "", "skill_2_percentage": 60, "seo_title": "", "skill_6_percentage": 40, "content_type": 14, "has_unpublished_changes": false, "expired": false, "pk": 3, "go_live_at": null, "promo_title": "Who am I?", "depth": 2, "skill_8_percentage": 30, "skill_7": "Angular", "locked": false, "body": "[{\\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"value\\": \\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra enim eu augue vehicula, nec malesuada risus dignissim. Vivamus mauris orci, interdum sit amet ullamcorper vel, pharetra a massa. Vivamus in pulvinar nisi. In hac habitasse platea dictumst. In vitae diam sed ligula congue consectetur nec laoreet urna. Mauris et tempus odio, et blandit felis. Pellentesque leo lorem, porttitor sed nisl a, dignissim maximus risus. Cras rhoncus ut justo vel elementum.</p>\\", \\"type\\": \\"paragraph_block\\"}]", "skill_1_percentage": 70, "title": "Home", "path": "00010001", "skill_5_percentage": 60, "hero_title": "Full Stack Developer", "owner": 1, "logo_image": null, "skill_8": "Ember.js", "numchild": 3, "featured_section_2_title": "Blog", "skill_4_percentage": 50, "show_in_menus": false, "featured_section_1_title": "Projects and Skills", "skill_9": "Java", "hero_text": "Andrew K. Telleria", "slug": "home", "skill_1": "Python", "featured_section_1": null, "skill_2": "Django", "skill_5": "HTML", "skill_6": "AWS", "latest_revision_created_at": "2018-09-07T03:19:08.050Z"}	\N	3	1
38	f	2019-02-19 20:14:30.608271+00	{"slug": "blog", "path": "000100010002", "last_published_at": "2018-08-23T00:36:21.021Z", "live_revision": 9, "numchild": 1, "owner": 1, "expired": false, "live": true, "url_path": "/home/blog/", "intro": "<p>Hey! Thanks for checking out my blog. I hope you find some of the things I wrote about helpful and interesting.</p>", "expire_at": null, "pk": 6, "has_unpublished_changes": false, "latest_revision_created_at": "2018-08-23T00:36:21.006Z", "draft_title": "Blog", "depth": 3, "show_in_menus": false, "title": "Blog", "content_type": 8, "locked": false, "go_live_at": null, "search_description": "", "first_published_at": "2018-08-23T00:36:21.021Z", "seo_title": ""}	\N	6	1
39	f	2019-02-19 20:23:05.653047+00	{"intro": "How I use GIT on my projects.", "body": "[{\\"id\\": \\"90d095f3-3892-41fd-a4ad-073667c11067\\", \\"type\\": \\"paragraph_block\\", \\"value\\": \\"<p> </p><p><b>Team Git Workflow</b></p><p>This is suppose to give a general idea on how a team git workflow should be. You can take this approach and apply it to anything that you are working on in a team environment. Git is a wonderful technology and has made it easy to keep everyone working on the project up to date with the code base.</p><p>Clone your repo to your local machine.</p><p>Switch to dev branch, if dev branch has not been created on remote repo use git checkout and set upstream. Verify dev branch is on remote repo.</p><p>Create a feature branch and name it the feature you are working on.</p><p>Usually there are multiple parts that make up a feature in a team environment, create the main-feature-branch and branch off into parts of the feature. </p><p>E.g. Main-feature-branch =&gt; shopping_cart</p><p>Sub-feature-branch =&gt; shopping_cart_logic</p><p>Sub-feature-branch =&gt; shopping_cart_styling</p><p>(In this example it would be a good idea to have the HTML in place before the sub branches are created)</p><p>Set upstream and push your initial commit.</p><p>Develop bits of the feature and commit the bits; push them to the remote repository.</p><p>Finish the feature and push the final changes to the remote repo; submit merge request on remote repo for the sub-feature-branch.</p><p>Merge sub-feature-branch into main-feature-branch on remote repository.</p><p>Delete your sub-feature-branch from local repo and from remote repo.</p><ol><li>git branch -d branch-name</li><li>git push origin \\\\u2014delete branch-name</li></ol><p>All parts of the main-feature-branch have been completed then submit merge request to dev branch. Merge the main-feature-branch into dev branch.</p><p>Delete the main-feature-branch.</p><p>Checkout into dev branch on local machine and pull down changes from remote repo dev branch to your local dev branch.</p><p>Rinse and repeat. Go back to the step where you branch off the dev branch into your feature branch.</p>\\"}]", "live": false, "has_unpublished_changes": false, "date": "2019-02-19", "draft_title": "Git Workflow", "latest_revision_created_at": null, "expire_at": null, "author": null, "show_in_menus": false, "seo_title": "", "locked": false, "title": "Git Workflow", "expired": false, "path": "0001000100020002", "numchild": 0, "tagged_items": [], "first_published_at": null, "search_description": "", "last_published_at": null, "go_live_at": null, "image": null, "feature": 0, "pk": 10, "content_type": 9, "owner": 1, "live_revision": null, "url_path": "/home/blog/git-workflow/", "slug": "git-workflow", "depth": 4}	\N	10	1
20	f	2018-09-10 15:35:52.271373+00	{"skill_7_percentage": 30, "featured_section_2": null, "image": null, "featured_section_2_title": "Blog", "hero_title": "Full Stack Developer", "featured_section_1": null, "draft_title": "Home", "path": "00010001", "skill_3_percentage": 50, "locked": false, "skill_8_percentage": 30, "skill_7": "Angular", "skill_8": "Ember.js", "go_live_at": null, "owner": 1, "skill_5": "HTML", "expire_at": null, "featured_section_1_title": "Projects and Skills", "skill_2_percentage": 60, "has_unpublished_changes": false, "promo_title": "Who am I?", "seo_title": "", "skill_9_percentage": 30, "skill_6": "AWS", "live_revision": 19, "expired": false, "title": "Home", "latest_revision_created_at": "2018-09-10T15:14:41.943Z", "depth": 2, "gallery_images": [], "url_path": "/home/", "first_published_at": "2018-08-17T00:45:28.074Z", "resume": 1, "show_in_menus": false, "skill_9": "Java", "skill_2": "Django", "skill_6_percentage": 40, "numchild": 3, "skill_4_percentage": 50, "promo_image": null, "slug": "home", "skill_1": "Python", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "content_type": 14, "pk": 3, "skill_1_percentage": 70, "logo_image": null, "skill_3": "JavaScript", "live": true, "hero_text": "Andrew K. Telleria", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I grew up in Salem, got my under grad at the University of Oregon, and now I reside in Portland. I attended Epicodus coding bootcamp to pursue a new career in tech and I have taught myself Python. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS.</p>", "last_published_at": "2018-09-10T15:14:41.968Z", "search_description": "", "skill_5_percentage": 60, "skill_4": "CSS"}	\N	3	1
23	f	2018-09-10 16:22:50.695496+00	{"image": null, "introduction": "About Page", "title": "About", "depth": 3, "expire_at": null, "url_path": "/home/about/", "body": "[{\\"value\\": \\"<p>Hello, thank you visiting my page. Here I will tell you a little about myself and how I wound up where I am today. I started my coding journey when I attended a coding bootcamp in Portland, Oregon named Epicodus. Prior to Epicodus I graduated from the University of Oregon with an Economics degree. The jobs that were available for my degree were in financial industry and that wasn&#x27;t an industry I wanted to be a part of. So out of college I started working retail until I honed in on what I wanted to do as a career. I needed a career that would feed my curiosity and my creativity. Computers were always something that seemed mysterious to me and it was something that I wanted to understand more considering everything in our modern world has been touched by a computer in one way or another. I did a couple Google searches and found out that there are code schools in the Portland area that cost significantly less than going back to under grad to get a Computer Science degree. I finally came down to Epicodus since it was a cost efficient coding school and it was 40 hours a week of intense programming. My only problem with Epicodus was that they didn&#x27;t really touch on the basics of Computer Science which I have taught myself some of the basics through free sources on the internet. What I took out of my experience at Epicodus was how to learn new technologies at a fast pace. What I enjoyed learning most was JavaScript. I really liked jQuery and the JavaScript frameworks Ember.js and Angular. After Epicodus is when I taught myself Python. I got a job at a small tech company doing some basic wordpress installations and SEO work. I didn&#x27;t feel that that my skills were being used and I wanted to explore other options. </p>\\", \\"id\\": \\"09574a6f-c77c-43c4-a8ae-bcf908a73b3f\\", \\"type\\": \\"paragraph_block\\"}]", "numchild": 0, "pk": 8, "expired": false, "draft_title": "About", "latest_revision_created_at": "2018-09-06T23:07:51.983Z", "path": "000100010003", "owner": 1, "seo_title": "", "has_unpublished_changes": false, "go_live_at": null, "last_published_at": "2018-09-06T23:07:52.002Z", "show_in_menus": false, "live_revision": 14, "search_description": "", "first_published_at": "2018-09-06T23:07:10.843Z", "content_type": 15, "slug": "about", "live": true, "locked": false}	\N	8	1
19	f	2018-09-10 15:14:41.943036+00	{"skill_7_percentage": 30, "featured_section_2": null, "image": null, "featured_section_2_title": "Blog", "hero_title": "Full Stack Developer", "featured_section_1": null, "draft_title": "Home", "path": "00010001", "skill_3_percentage": 50, "locked": false, "skill_8_percentage": 30, "skill_7": "Angular", "skill_8": "Ember.js", "go_live_at": null, "owner": 1, "skill_5": "HTML", "expire_at": null, "featured_section_1_title": "Projects and Skills", "skill_2_percentage": 60, "has_unpublished_changes": false, "promo_title": "Who am I?", "seo_title": "", "skill_9_percentage": 30, "skill_6": "AWS", "live_revision": 18, "expired": false, "title": "Home", "latest_revision_created_at": "2018-09-07T03:21:24.026Z", "depth": 2, "gallery_images": [], "url_path": "/home/", "first_published_at": "2018-08-17T00:45:28.074Z", "resume": 1, "show_in_menus": false, "skill_9": "Java", "skill_2": "Django", "skill_6_percentage": 40, "numchild": 3, "skill_4_percentage": 50, "promo_image": null, "slug": "home", "skill_1": "Python", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "content_type": 14, "pk": 3, "skill_1_percentage": 70, "logo_image": null, "skill_3": "JavaScript", "live": true, "hero_text": "Andrew K. Telleria", "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I grew up in Salem, got my under grad at the University of Oregon, and now I reside in Portland. I attended Epicodus coding bootcamp to pursue a new career in tech and I have taught myself Python. I specialize in Python and Django and have experience deploying web applications using AWS.</p>", "last_published_at": "2018-09-07T03:21:24.047Z", "search_description": "", "skill_5_percentage": 60, "skill_4": "CSS"}	\N	3	1
25	f	2018-10-25 22:41:49.16037+00	{"expired": false, "path": "00010001", "skills": [{"sort_order": 0, "page": 3, "skill": "Python", "percentage": 60, "pk": null}, {"sort_order": 1, "page": 3, "skill": "Django", "percentage": 55, "pk": null}, {"sort_order": 2, "page": 3, "skill": "JavaScript", "percentage": 50, "pk": null}, {"sort_order": 3, "page": 3, "skill": "HTML", "percentage": 50, "pk": null}, {"sort_order": 4, "page": 3, "skill": "CSS", "percentage": 40, "pk": null}, {"sort_order": 5, "page": 3, "skill": "Java", "percentage": 35, "pk": null}, {"sort_order": 6, "page": 3, "skill": "AWS", "percentage": 35, "pk": null}, {"sort_order": 7, "page": 3, "skill": "Angular", "percentage": 30, "pk": null}, {"sort_order": 8, "page": 3, "skill": "Android", "percentage": 30, "pk": null}], "draft_title": "Home", "first_published_at": "2018-08-17T00:45:28.074Z", "locked": false, "live": true, "seo_title": "", "content_type": 14, "owner": 1, "featured_section_2": null, "numchild": 3, "last_published_at": "2018-09-10T16:31:39.445Z", "slug": "home", "gallery_images": [], "promo_text": "<p>My name is Andrew Keenan Telleria, born and raised in Oregon. I have experience building full stack applications using the technologies Python, vanilla JavaScript, CSS, and Django. I specialize in Python/Django and have experience deploying web applications to an IaaS specifically AWS.</p>", "has_unpublished_changes": false, "promo_title": "Who am I?", "show_in_menus": false, "title": "Home", "body": "[{\\"value\\": \\"<p>Hello, please take a look at my resume and feel free to contact me about any questions you have. I don&#x27;t mind setting up informational meetings to get to know more about you and your organization. I also don&#x27;t mind talking shop with anyone and potentially making a new friend.</p>\\", \\"id\\": \\"38a60420-fd24-4c7d-a3a9-83e934a9951f\\", \\"type\\": \\"paragraph_block\\"}]", "url_path": "/home/", "featured_section_1_title": "Projects and Skills", "depth": 2, "featured_section_1": null, "promo_image": 15, "pk": 3, "resume": 1, "featured_section_2_title": "Blog", "hero_text": "Andrew K. Telleria", "go_live_at": null, "latest_revision_created_at": "2018-09-10T16:31:39.421Z", "hero_title": "Full Stack Developer", "expire_at": null, "live_revision": 24, "search_description": ""}	\N	3	1
10	f	2018-08-23 00:37:33.09318+00	{"expired": false, "date": "2018-07-12", "github": "https://github.com/AndrewTelleria/phi", "seo_title": "", "numchild": 0, "body": "[{\\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\", \\"type\\": \\"paragraph\\"}]", "live_revision": 6, "show_in_menus": false, "has_unpublished_changes": false, "draft_title": "Pup House Inn", "depth": 4, "expire_at": null, "image": 13, "url_path": "/home/projects/pup-house-inn/", "project_url": "http://www.pup-house.com", "last_published_at": "2018-08-17T16:54:16.115Z", "feature": 1, "path": "0001000100010001", "search_description": "", "go_live_at": null, "locked": false, "live": true, "first_published_at": "2018-08-17T16:34:14.364Z", "owner": 1, "content_type": 17, "title": "Pup House Inn", "slug": "pup-house-inn", "pk": 5, "gallery_images": [{"page": 5, "pk": 2, "image": 6, "caption": "Homepage Services", "sort_order": 1}, {"page": 5, "pk": 3, "image": 5, "caption": "Homepage About", "sort_order": 2}, {"page": 5, "pk": 5, "image": 10, "caption": "Homepage Photo Gallery and Footer", "sort_order": 4}, {"page": 5, "pk": 6, "image": 7, "caption": "Services Page", "sort_order": 5}, {"page": 5, "pk": 7, "image": 9, "caption": "Blog Page", "sort_order": 6}], "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "latest_revision_created_at": "2018-08-17T16:54:16.075Z"}	\N	5	1
26	f	2018-10-25 22:52:02.674324+00	{"has_unpublished_changes": false, "url_path": "/home/projects/pup-house-inn/", "image": 14, "go_live_at": null, "feature": 1, "show_in_menus": false, "github": "https://github.com/AndrewTelleria/phi", "live": true, "seo_title": "", "date": "2018-07-12", "gallery_images": [{"pk": 2, "sort_order": 1, "caption": "Homepage Services", "page": 5, "image": 6}, {"pk": 3, "sort_order": 2, "caption": "Homepage About", "page": 5, "image": 5}, {"pk": 5, "sort_order": 4, "caption": "Homepage Photo Gallery and Footer", "page": 5, "image": 10}, {"pk": 6, "sort_order": 5, "caption": "Services Page", "page": 5, "image": 7}, {"pk": 7, "sort_order": 6, "caption": "Blog Page", "page": 5, "image": 9}], "content_type": 17, "latest_revision_created_at": "2018-09-06T23:13:11.002Z", "live_revision": 15, "title": "Pup House Inn", "last_published_at": "2018-09-06T23:13:11.036Z", "path": "0001000100010001", "search_description": "", "expire_at": null, "project_url": null, "body": "[{\\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "numchild": 0, "draft_title": "Pup House Inn", "pk": 5, "slug": "pup-house-inn", "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "expired": false, "depth": 4, "first_published_at": "2018-08-17T16:34:14.364Z", "owner": 1, "locked": false}	\N	5	1
6	f	2018-08-17 16:54:16.075552+00	{"go_live_at": null, "numchild": 0, "draft_title": "Pup House Inn", "body": "[{\\"type\\": \\"paragraph\\", \\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "last_published_at": "2018-08-17T16:45:39.661Z", "seo_title": "", "title": "Pup House Inn", "live": true, "locked": false, "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "show_in_menus": false, "expired": false, "project_url": "http://www.pup-house.com", "date": "2018-07-12", "image": 2, "has_unpublished_changes": false, "depth": 4, "url_path": "/home/projects/pup-house-inn/", "path": "0001000100010001", "expire_at": null, "search_description": "", "feature": 1, "gallery_images": [{"image": 11, "caption": "Hero section", "page": 5, "pk": null, "sort_order": 0}, {"image": 6, "caption": "Homepage Services", "page": 5, "pk": null, "sort_order": 1}, {"image": 5, "caption": "Homepage About", "page": 5, "pk": null, "sort_order": 2}, {"image": 4, "caption": "Homepage Blog", "page": 5, "pk": null, "sort_order": 3}, {"image": 10, "caption": "Homepage Photo Gallery and Footer", "page": 5, "pk": null, "sort_order": 4}, {"image": 7, "caption": "Services Page", "page": 5, "pk": null, "sort_order": 5}, {"image": 9, "caption": "Blog Page", "page": 5, "pk": null, "sort_order": 6}, {"image": 8, "caption": "Photo Gallery", "page": 5, "pk": null, "sort_order": 7}], "owner": 1, "live_revision": 5, "slug": "pup-house-inn", "github": "https://github.com/AndrewTelleria/phi", "content_type": 17, "pk": 5, "first_published_at": "2018-08-17T16:34:14.364Z", "latest_revision_created_at": "2018-08-17T16:45:39.641Z"}	\N	5	1
15	f	2018-09-06 23:13:11.002916+00	{"draft_title": "Pup House Inn", "path": "0001000100010001", "depth": 4, "slug": "pup-house-inn", "owner": 1, "project_url": "http://www.pup-house.com", "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "latest_revision_created_at": "2018-08-23T00:37:33.093Z", "date": "2018-07-12", "pk": 5, "expired": false, "image": 14, "content_type": 17, "search_description": "", "live": true, "title": "Pup House Inn", "show_in_menus": false, "live_revision": 10, "github": "https://github.com/AndrewTelleria/phi", "seo_title": "", "feature": 1, "numchild": 0, "gallery_images": [{"image": 6, "pk": 2, "sort_order": 1, "caption": "Homepage Services", "page": 5}, {"image": 5, "pk": 3, "sort_order": 2, "caption": "Homepage About", "page": 5}, {"image": 10, "pk": 5, "sort_order": 4, "caption": "Homepage Photo Gallery and Footer", "page": 5}, {"image": 7, "pk": 6, "sort_order": 5, "caption": "Services Page", "page": 5}, {"image": 9, "pk": 7, "sort_order": 6, "caption": "Blog Page", "page": 5}], "url_path": "/home/projects/pup-house-inn/", "first_published_at": "2018-08-17T16:34:14.364Z", "go_live_at": null, "expire_at": null, "locked": false, "has_unpublished_changes": false, "body": "[{\\"type\\": \\"paragraph\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\", \\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\"}]", "last_published_at": "2018-08-23T00:37:33.125Z"}	\N	5	1
27	f	2018-10-25 22:52:55.650734+00	{"has_unpublished_changes": false, "url_path": "/home/projects/pup-house-inn/", "image": 14, "go_live_at": null, "feature": 1, "show_in_menus": false, "github": "https://github.com/AndrewTelleria/phi", "live": true, "seo_title": "", "date": "2018-07-12", "gallery_images": [{"pk": 2, "sort_order": 1, "caption": "Homepage Services", "page": 5, "image": 6}, {"pk": 3, "sort_order": 2, "caption": "Homepage About", "page": 5, "image": 5}, {"pk": 5, "sort_order": 4, "caption": "Homepage Photo Gallery and Footer", "page": 5, "image": 10}, {"pk": 7, "sort_order": 6, "caption": "Blog Page", "page": 5, "image": 9}], "content_type": 17, "latest_revision_created_at": "2018-10-25T22:52:02.674Z", "live_revision": 26, "title": "Pup House Inn", "last_published_at": "2018-10-25T22:52:02.709Z", "path": "0001000100010001", "search_description": "", "expire_at": null, "project_url": null, "body": "[{\\"value\\": \\"<p>I built this website using Django and Wagtail. Wagtail is a CMS that is built on top of Django. I truly enjoyed working with Wagtail and Django for that matter because of the wealth of documentation that is online. The user interface inside of the CMS is intuitive and pleasing to the eyes. I did a lot of front end work on the website too. The manager of the business was an amateur photographer and wanted a feature that would display his work. I constructed a photo gallery feature for him to upload pictures. There is also a blog that would let them write about getting the business started and other things that would go on in their life. Services were also displayed and the home page was customizable allowing the user to organize the services in a hierarchical order they would want a potential customer to see displaying their highlighted services right on the front page. Unfortunately, the business never made it off the ground but I enjoyed working on the website so much that I decided to keep it to show off my work. If you have questions, please send me an email.</p>\\", \\"type\\": \\"paragraph\\", \\"id\\": \\"3726733a-4548-494a-aa0e-71ee3b5abd2c\\"}]", "numchild": 0, "draft_title": "Pup House Inn", "pk": 5, "slug": "pup-house-inn", "intro": "This was a website for an animal boarding business that resided in Washington. It is a CMS built on top of Django.", "expired": false, "depth": 4, "first_published_at": "2018-08-17T16:34:14.364Z", "owner": 1, "locked": false}	\N	5	1
\.


--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_pagerevision_id_seq', 39, true);


--
-- Data for Name: wagtailcore_pageviewrestriction; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_pageviewrestriction (id, password, page_id, restriction_type) FROM stdin;
\.


--
-- Data for Name: wagtailcore_pageviewrestriction_groups; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_pageviewrestriction_groups (id, pageviewrestriction_id, group_id) FROM stdin;
\.


--
-- Name: wagtailcore_pageviewrestriction_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_pageviewrestriction_groups_id_seq', 1, false);


--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_pageviewrestriction_id_seq', 1, false);


--
-- Data for Name: wagtailcore_site; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailcore_site (id, hostname, port, is_default_site, root_page_id, site_name) FROM stdin;
2	localhost	80	t	3	Home
\.


--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailcore_site_id_seq', 2, true);


--
-- Data for Name: wagtaildocs_document; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtaildocs_document (id, title, file, created_at, uploaded_by_user_id, collection_id, file_size, file_hash) FROM stdin;
1	Andrew_K_Telleria_Resume.pdf	documents/Andrew_K_Telleria_Resume_K9IqoJ7.pdf	2018-09-07 03:15:03.06677+00	1	1	\N	
\.


--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtaildocs_document_id_seq', 1, true);


--
-- Data for Name: wagtailembeds_embed; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailembeds_embed (id, url, max_width, type, html, title, author_name, provider_name, thumbnail_url, width, height, last_updated) FROM stdin;
\.


--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailembeds_embed_id_seq', 1, false);


--
-- Data for Name: wagtailforms_formsubmission; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailforms_formsubmission (id, form_data, submit_time, page_id) FROM stdin;
\.


--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailforms_formsubmission_id_seq', 1, false);


--
-- Data for Name: wagtailimages_image; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailimages_image (id, title, file, width, height, created_at, focal_point_x, focal_point_y, focal_point_width, focal_point_height, uploaded_by_user_id, file_size, collection_id, file_hash) FROM stdin;
5	pup_house_homepage_body.png	original_images/pup_house_homepage_body.png	800	437	2018-08-17 16:51:08.971226+00	\N	\N	\N	\N	1	686254	1	
6	pup_house_homepage_services.png	original_images/pup_house_homepage_services.png	800	442	2018-08-17 16:51:09.343549+00	\N	\N	\N	\N	1	369401	1	
7	pup_house_services.png	original_images/pup_house_services.png	800	440	2018-08-17 16:51:09.842917+00	\N	\N	\N	\N	1	568788	1	
9	pup_house_blog.png	original_images/pup_house_blog.png	800	506	2018-08-17 16:51:10.847632+00	\N	\N	\N	\N	1	538230	1	
10	pup_house_footer.png	original_images/pup_house_footer.png	800	506	2018-08-17 16:51:11.325888+00	\N	\N	\N	\N	1	558676	1	
14	pup_house_hero.png	original_images/pup_house_hero.png	800	505	2018-09-06 23:12:56.544124+00	\N	\N	\N	\N	1	746496	1	
15	AndrewT_profile.jpg	original_images/AndrewT_profile.jpg	1000	1000	2018-09-10 15:36:03.421534+00	\N	\N	\N	\N	1	177467	1	
16	wagtail	original_images/wagtail.jpg	1280	853	2018-11-01 19:58:03.510558+00	\N	\N	\N	\N	1	\N	1	
17	wagtail	original_images/wagtail_5Hl4exv.jpg	1024	683	2018-11-01 20:05:23.535779+00	\N	\N	\N	\N	1	\N	1	
18	wagtail	original_images/white-wagtail-1526089_1280.jpg	1280	853	2018-11-01 20:09:31.874253+00	\N	\N	\N	\N	1	\N	1	
19	wagtail	original_images/wagtail_mm9tIWW.jpg	1280	896	2018-11-01 20:12:43.707227+00	\N	\N	\N	\N	1	\N	1	
\.


--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailimages_image_id_seq', 19, true);


--
-- Data for Name: wagtailimages_rendition; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailimages_rendition (id, file, width, height, focal_point_key, image_id, filter_spec) FROM stdin;
10	images/pup_house_footer.max-165x165.png	165	104		10	max-165x165
11	images/pup_house_blog.max-165x165.png	165	104		9	max-165x165
13	images/pup_house_services.max-165x165.png	165	90		7	max-165x165
14	images/pup_house_homepage_services.max-165x165.png	165	91		6	max-165x165
15	images/pup_house_homepage_body.max-165x165.png	165	90		5	max-165x165
18	images/pup_house_homepage_services.width-900.png	800	442		6	width-900
19	images/pup_house_homepage_body.width-900.png	800	437		5	width-900
21	images/pup_house_footer.width-900.png	800	506		10	width-900
22	images/pup_house_services.width-900.png	800	440		7	width-900
23	images/pup_house_blog.width-900.png	800	506		9	width-900
31	images/pup_house_hero.max-165x165.png	165	104		14	max-165x165
32	images/pup_house_hero.2e16d0ba.fill-500x400-c100.png	500	400	2e16d0ba	14	fill-500x400-c100
33	images/pup_house_hero.2e16d0ba.fill-300x200-c100.png	300	200	2e16d0ba	14	fill-300x200-c100
34	images/AndrewT_profile.max-165x165.jpg	165	165		15	max-165x165
35	images/AndrewT_profile.2e16d0ba.fill-300x200-c100.jpg	300	200	2e16d0ba	15	fill-300x200-c100
36	images/AndrewT_profile.2e16d0ba.fill-600x550-c100.jpg	600	550	2e16d0ba	15	fill-600x550-c100
37	images/AndrewT_profile.2e16d0ba.fill-600x450-c100.jpg	600	450	2e16d0ba	15	fill-600x450-c100
38	images/wagtail.max-165x165.jpg	165	109		16	max-165x165
39	images/wagtail.min-900x500.jpg	900	599		16	min-900x500
40	images/wagtail_5Hl4exv.max-165x165.jpg	165	110		17	max-165x165
41	images/wagtail_5Hl4exv.min-900x500.jpg	900	600		17	min-900x500
42	images/white-wagtail-1526089_1280.max-165x165.jpg	165	109		18	max-165x165
43	images/white-wagtail-1526089_1280.min-900x500.jpg	900	599		18	min-900x500
44	images/wagtail_mm9tIWW.max-165x165.jpg	165	115		19	max-165x165
45	images/wagtail_mm9tIWW.min-900x500.jpg	900	630		19	min-900x500
\.


--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailimages_rendition_id_seq', 45, true);


--
-- Data for Name: wagtailredirects_redirect; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailredirects_redirect (id, old_path, is_permanent, redirect_link, redirect_page_id, site_id) FROM stdin;
\.


--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailredirects_redirect_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_editorspick; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailsearch_editorspick (id, sort_order, description, page_id, query_id) FROM stdin;
\.


--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailsearch_editorspick_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_query; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailsearch_query (id, query_string) FROM stdin;
\.


--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailsearch_query_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_querydailyhits; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailsearch_querydailyhits (id, date, hits, query_id) FROM stdin;
\.


--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailsearch_querydailyhits_id_seq', 1, false);


--
-- Data for Name: wagtailusers_userprofile; Type: TABLE DATA; Schema: public; Owner: andrew
--

COPY public.wagtailusers_userprofile (id, submitted_notifications, approved_notifications, rejected_notifications, user_id, preferred_language, current_time_zone, avatar) FROM stdin;
\.


--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: andrew
--

SELECT pg_catalog.setval('public.wagtailusers_userprofile_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: blog_blogindexpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogindexpage
    ADD CONSTRAINT blog_blogindexpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: blog_blogpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpage
    ADD CONSTRAINT blog_blogpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: blog_blogpagetag_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpagetag
    ADD CONSTRAINT blog_blogpagetag_pkey PRIMARY KEY (id);


--
-- Name: blog_blogtagindexpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogtagindexpage
    ADD CONSTRAINT blog_blogtagindexpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: home_homepage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_homepageimagegallery_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepageimagegallery
    ADD CONSTRAINT home_homepageimagegallery_pkey PRIMARY KEY (id);


--
-- Name: home_people_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_people
    ADD CONSTRAINT home_people_pkey PRIMARY KEY (id);


--
-- Name: home_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_skills
    ADD CONSTRAINT home_skills_pkey PRIMARY KEY (id);


--
-- Name: home_standardpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_standardpage
    ADD CONSTRAINT home_standardpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: projects_projectindexpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectindexpage
    ADD CONSTRAINT projects_projectindexpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: projects_projectpage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpage
    ADD CONSTRAINT projects_projectpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: projects_projectpagegalleryimage_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpagegalleryimage
    ADD CONSTRAINT projects_projectpagegalleryimage_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_collection_path_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collection
    ADD CONSTRAINT wagtailcore_collection_path_key UNIQUE (path);


--
-- Name: wagtailcore_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collection
    ADD CONSTRAINT wagtailcore_collection_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_collectionvi_collectionviewrestrictio_988995ae_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction_groups
    ADD CONSTRAINT wagtailcore_collectionvi_collectionviewrestrictio_988995ae_uniq UNIQUE (collectionviewrestriction_id, group_id);


--
-- Name: wagtailcore_collectionviewrestriction_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction_groups
    ADD CONSTRAINT wagtailcore_collectionviewrestriction_groups_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_collectionviewrestriction_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction
    ADD CONSTRAINT wagtailcore_collectionviewrestriction_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_groupcollect_group_id_collection_id_p_a21cefe9_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission
    ADD CONSTRAINT wagtailcore_groupcollect_group_id_collection_id_p_a21cefe9_uniq UNIQUE (group_id, collection_id, permission_id);


--
-- Name: wagtailcore_groupcollectionpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission
    ADD CONSTRAINT wagtailcore_groupcollectionpermission_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_grouppageper_group_id_page_id_permiss_0898bdf8_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppageper_group_id_page_id_permiss_0898bdf8_uniq UNIQUE (group_id, page_id, permission_type);


--
-- Name: wagtailcore_grouppagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppagepermission_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_page_path_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_path_key UNIQUE (path);


--
-- Name: wagtailcore_page_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_pagerevision_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_pagerevision_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_pageviewrest_pageviewrestriction_id_g_d23f80bb_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction_groups
    ADD CONSTRAINT wagtailcore_pageviewrest_pageviewrestriction_id_g_d23f80bb_uniq UNIQUE (pageviewrestriction_id, group_id);


--
-- Name: wagtailcore_pageviewrestriction_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction_groups
    ADD CONSTRAINT wagtailcore_pageviewrestriction_groups_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_pageviewrestriction_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction
    ADD CONSTRAINT wagtailcore_pageviewrestriction_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_site_hostname_port_2c626d70_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_site
    ADD CONSTRAINT wagtailcore_site_hostname_port_2c626d70_uniq UNIQUE (hostname, port);


--
-- Name: wagtailcore_site_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_site
    ADD CONSTRAINT wagtailcore_site_pkey PRIMARY KEY (id);


--
-- Name: wagtaildocs_document_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtaildocs_document
    ADD CONSTRAINT wagtaildocs_document_pkey PRIMARY KEY (id);


--
-- Name: wagtailembeds_embed_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailembeds_embed
    ADD CONSTRAINT wagtailembeds_embed_pkey PRIMARY KEY (id);


--
-- Name: wagtailembeds_embed_url_max_width_8a2922d8_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailembeds_embed
    ADD CONSTRAINT wagtailembeds_embed_url_max_width_8a2922d8_uniq UNIQUE (url, max_width);


--
-- Name: wagtailforms_formsubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailforms_formsubmission
    ADD CONSTRAINT wagtailforms_formsubmission_pkey PRIMARY KEY (id);


--
-- Name: wagtailimages_image_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_image
    ADD CONSTRAINT wagtailimages_image_pkey PRIMARY KEY (id);


--
-- Name: wagtailimages_rendition_image_id_filter_spec_foc_323c8fe0_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_rendition
    ADD CONSTRAINT wagtailimages_rendition_image_id_filter_spec_foc_323c8fe0_uniq UNIQUE (image_id, filter_spec, focal_point_key);


--
-- Name: wagtailimages_rendition_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_rendition
    ADD CONSTRAINT wagtailimages_rendition_pkey PRIMARY KEY (id);


--
-- Name: wagtailredirects_redirect_old_path_site_id_783622d7_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_redirect_old_path_site_id_783622d7_uniq UNIQUE (old_path, site_id);


--
-- Name: wagtailredirects_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_redirect_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_editorspick_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsearch_editorspick_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_query_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_query
    ADD CONSTRAINT wagtailsearch_query_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_query_query_string_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_query
    ADD CONSTRAINT wagtailsearch_query_query_string_key UNIQUE (query_string);


--
-- Name: wagtailsearch_querydailyhits_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsearch_querydailyhits_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_querydailyhits_query_id_date_1dd232e6_uniq; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsearch_querydailyhits_query_id_date_1dd232e6_uniq UNIQUE (query_id, date);


--
-- Name: wagtailusers_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_userprofile_pkey PRIMARY KEY (id);


--
-- Name: wagtailusers_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: blog_blogpage_author_id_8c179cec; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX blog_blogpage_author_id_8c179cec ON public.blog_blogpage USING btree (author_id);


--
-- Name: blog_blogpage_image_id_a60e2e91; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX blog_blogpage_image_id_a60e2e91 ON public.blog_blogpage USING btree (image_id);


--
-- Name: blog_blogpagetag_content_object_id_0dc644d2; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX blog_blogpagetag_content_object_id_0dc644d2 ON public.blog_blogpagetag USING btree (content_object_id);


--
-- Name: blog_blogpagetag_tag_id_81dc0e5f; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX blog_blogpagetag_tag_id_81dc0e5f ON public.blog_blogpagetag USING btree (tag_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: home_homepage_featured_section_1_id_e534fc28; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepage_featured_section_1_id_e534fc28 ON public.home_homepage USING btree (featured_section_1_id);


--
-- Name: home_homepage_featured_section_2_id_d578d895; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepage_featured_section_2_id_d578d895 ON public.home_homepage USING btree (featured_section_2_id);


--
-- Name: home_homepage_promo_image_id_afb37fd6; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepage_promo_image_id_afb37fd6 ON public.home_homepage USING btree (promo_image_id);


--
-- Name: home_homepage_resume_id_12b2dcc6; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepage_resume_id_12b2dcc6 ON public.home_homepage USING btree (resume_id);


--
-- Name: home_homepageimagegallery_image_id_d9c1ad51; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepageimagegallery_image_id_d9c1ad51 ON public.home_homepageimagegallery USING btree (image_id);


--
-- Name: home_homepageimagegallery_page_id_fc7957cc; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_homepageimagegallery_page_id_fc7957cc ON public.home_homepageimagegallery USING btree (page_id);


--
-- Name: home_people_image_id_7999b56e; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_people_image_id_7999b56e ON public.home_people USING btree (image_id);


--
-- Name: home_skills_page_id_f45d6f6c; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_skills_page_id_f45d6f6c ON public.home_skills USING btree (page_id);


--
-- Name: home_standardpage_image_id_bd2b3ffc; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX home_standardpage_image_id_bd2b3ffc ON public.home_standardpage USING btree (image_id);


--
-- Name: projects_projectpage_image_id_d50212f0; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX projects_projectpage_image_id_d50212f0 ON public.projects_projectpage USING btree (image_id);


--
-- Name: projects_projectpagegalleryimage_image_id_809a87d8; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX projects_projectpagegalleryimage_image_id_809a87d8 ON public.projects_projectpagegalleryimage USING btree (image_id);


--
-- Name: projects_projectpagegalleryimage_page_id_d646f194; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX projects_projectpagegalleryimage_page_id_d646f194 ON public.projects_projectpagegalleryimage USING btree (page_id);


--
-- Name: taggit_tag_name_58eb2ed9_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_tag_name_58eb2ed9_like ON public.taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_6be58b2c_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_tag_slug_6be58b2c_like ON public.taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_taggeditem_content_type_id_9957a03c; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_taggeditem_content_type_id_9957a03c ON public.taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_content_type_id_object_id_196cc965_idx; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_taggeditem_content_type_id_object_id_196cc965_idx ON public.taggit_taggeditem USING btree (content_type_id, object_id);


--
-- Name: taggit_taggeditem_object_id_e2d7d1df; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_taggeditem_object_id_e2d7d1df ON public.taggit_taggeditem USING btree (object_id);


--
-- Name: taggit_taggeditem_tag_id_f4f5b767; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX taggit_taggeditem_tag_id_f4f5b767 ON public.taggit_taggeditem USING btree (tag_id);


--
-- Name: wagtailcore_collection_path_d848dc19_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_collection_path_d848dc19_like ON public.wagtailcore_collection USING btree (path varchar_pattern_ops);


--
-- Name: wagtailcore_collectionview_collectionviewrestriction__47320efd; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_collectionview_collectionviewrestriction__47320efd ON public.wagtailcore_collectionviewrestriction_groups USING btree (collectionviewrestriction_id);


--
-- Name: wagtailcore_collectionviewrestriction_collection_id_761908ec; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_collectionviewrestriction_collection_id_761908ec ON public.wagtailcore_collectionviewrestriction USING btree (collection_id);


--
-- Name: wagtailcore_collectionviewrestriction_groups_group_id_1823f2a3; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_collectionviewrestriction_groups_group_id_1823f2a3 ON public.wagtailcore_collectionviewrestriction_groups USING btree (group_id);


--
-- Name: wagtailcore_groupcollectionpermission_collection_id_5423575a; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_groupcollectionpermission_collection_id_5423575a ON public.wagtailcore_groupcollectionpermission USING btree (collection_id);


--
-- Name: wagtailcore_groupcollectionpermission_group_id_05d61460; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_groupcollectionpermission_group_id_05d61460 ON public.wagtailcore_groupcollectionpermission USING btree (group_id);


--
-- Name: wagtailcore_groupcollectionpermission_permission_id_1b626275; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_groupcollectionpermission_permission_id_1b626275 ON public.wagtailcore_groupcollectionpermission USING btree (permission_id);


--
-- Name: wagtailcore_grouppagepermission_group_id_fc07e671; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_grouppagepermission_group_id_fc07e671 ON public.wagtailcore_grouppagepermission USING btree (group_id);


--
-- Name: wagtailcore_grouppagepermission_page_id_710b114a; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_grouppagepermission_page_id_710b114a ON public.wagtailcore_grouppagepermission USING btree (page_id);


--
-- Name: wagtailcore_page_content_type_id_c28424df; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_content_type_id_c28424df ON public.wagtailcore_page USING btree (content_type_id);


--
-- Name: wagtailcore_page_first_published_at_2b5dd637; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_first_published_at_2b5dd637 ON public.wagtailcore_page USING btree (first_published_at);


--
-- Name: wagtailcore_page_live_revision_id_930bd822; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_live_revision_id_930bd822 ON public.wagtailcore_page USING btree (live_revision_id);


--
-- Name: wagtailcore_page_owner_id_fbf7c332; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_owner_id_fbf7c332 ON public.wagtailcore_page USING btree (owner_id);


--
-- Name: wagtailcore_page_path_98eba2c8_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_path_98eba2c8_like ON public.wagtailcore_page USING btree (path varchar_pattern_ops);


--
-- Name: wagtailcore_page_slug_e7c11b8f; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_slug_e7c11b8f ON public.wagtailcore_page USING btree (slug);


--
-- Name: wagtailcore_page_slug_e7c11b8f_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_page_slug_e7c11b8f_like ON public.wagtailcore_page USING btree (slug varchar_pattern_ops);


--
-- Name: wagtailcore_pagerevision_created_at_66954e3b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pagerevision_created_at_66954e3b ON public.wagtailcore_pagerevision USING btree (created_at);


--
-- Name: wagtailcore_pagerevision_page_id_d421cc1d; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pagerevision_page_id_d421cc1d ON public.wagtailcore_pagerevision USING btree (page_id);


--
-- Name: wagtailcore_pagerevision_submitted_for_moderation_c682e44c; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pagerevision_submitted_for_moderation_c682e44c ON public.wagtailcore_pagerevision USING btree (submitted_for_moderation);


--
-- Name: wagtailcore_pagerevision_user_id_2409d2f4; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pagerevision_user_id_2409d2f4 ON public.wagtailcore_pagerevision USING btree (user_id);


--
-- Name: wagtailcore_pageviewrestri_pageviewrestriction_id_f147a99a; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pageviewrestri_pageviewrestriction_id_f147a99a ON public.wagtailcore_pageviewrestriction_groups USING btree (pageviewrestriction_id);


--
-- Name: wagtailcore_pageviewrestriction_groups_group_id_6460f223; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pageviewrestriction_groups_group_id_6460f223 ON public.wagtailcore_pageviewrestriction_groups USING btree (group_id);


--
-- Name: wagtailcore_pageviewrestriction_page_id_15a8bea6; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_pageviewrestriction_page_id_15a8bea6 ON public.wagtailcore_pageviewrestriction USING btree (page_id);


--
-- Name: wagtailcore_site_hostname_96b20b46; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_site_hostname_96b20b46 ON public.wagtailcore_site USING btree (hostname);


--
-- Name: wagtailcore_site_hostname_96b20b46_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_site_hostname_96b20b46_like ON public.wagtailcore_site USING btree (hostname varchar_pattern_ops);


--
-- Name: wagtailcore_site_root_page_id_e02fb95c; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailcore_site_root_page_id_e02fb95c ON public.wagtailcore_site USING btree (root_page_id);


--
-- Name: wagtaildocs_document_collection_id_23881625; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtaildocs_document_collection_id_23881625 ON public.wagtaildocs_document USING btree (collection_id);


--
-- Name: wagtaildocs_document_uploaded_by_user_id_17258b41; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtaildocs_document_uploaded_by_user_id_17258b41 ON public.wagtaildocs_document USING btree (uploaded_by_user_id);


--
-- Name: wagtailforms_formsubmission_page_id_e48e93e7; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailforms_formsubmission_page_id_e48e93e7 ON public.wagtailforms_formsubmission USING btree (page_id);


--
-- Name: wagtailimages_image_collection_id_c2f8af7e; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_image_collection_id_c2f8af7e ON public.wagtailimages_image USING btree (collection_id);


--
-- Name: wagtailimages_image_created_at_86fa6cd4; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_image_created_at_86fa6cd4 ON public.wagtailimages_image USING btree (created_at);


--
-- Name: wagtailimages_image_uploaded_by_user_id_5d73dc75; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_image_uploaded_by_user_id_5d73dc75 ON public.wagtailimages_image USING btree (uploaded_by_user_id);


--
-- Name: wagtailimages_rendition_filter_spec_1cba3201; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_rendition_filter_spec_1cba3201 ON public.wagtailimages_rendition USING btree (filter_spec);


--
-- Name: wagtailimages_rendition_filter_spec_1cba3201_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_rendition_filter_spec_1cba3201_like ON public.wagtailimages_rendition USING btree (filter_spec varchar_pattern_ops);


--
-- Name: wagtailimages_rendition_image_id_3e1fd774; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailimages_rendition_image_id_3e1fd774 ON public.wagtailimages_rendition USING btree (image_id);


--
-- Name: wagtailredirects_redirect_old_path_bb35247b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailredirects_redirect_old_path_bb35247b ON public.wagtailredirects_redirect USING btree (old_path);


--
-- Name: wagtailredirects_redirect_old_path_bb35247b_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailredirects_redirect_old_path_bb35247b_like ON public.wagtailredirects_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: wagtailredirects_redirect_redirect_page_id_b5728a8f; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailredirects_redirect_redirect_page_id_b5728a8f ON public.wagtailredirects_redirect USING btree (redirect_page_id);


--
-- Name: wagtailredirects_redirect_site_id_780a0e1e; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailredirects_redirect_site_id_780a0e1e ON public.wagtailredirects_redirect USING btree (site_id);


--
-- Name: wagtailsearch_editorspick_page_id_28cbc274; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailsearch_editorspick_page_id_28cbc274 ON public.wagtailsearch_editorspick USING btree (page_id);


--
-- Name: wagtailsearch_editorspick_query_id_c6eee4a0; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailsearch_editorspick_query_id_c6eee4a0 ON public.wagtailsearch_editorspick USING btree (query_id);


--
-- Name: wagtailsearch_query_query_string_e785ea07_like; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailsearch_query_query_string_e785ea07_like ON public.wagtailsearch_query USING btree (query_string varchar_pattern_ops);


--
-- Name: wagtailsearch_querydailyhits_query_id_2185994b; Type: INDEX; Schema: public; Owner: andrew
--

CREATE INDEX wagtailsearch_querydailyhits_query_id_2185994b ON public.wagtailsearch_querydailyhits USING btree (query_id);


--
-- Name: auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogindexpage_page_ptr_id_d87c3ac2_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogindexpage
    ADD CONSTRAINT blog_blogindexpage_page_ptr_id_d87c3ac2_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpage_author_id_8c179cec_fk_home_people_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpage
    ADD CONSTRAINT blog_blogpage_author_id_8c179cec_fk_home_people_id FOREIGN KEY (author_id) REFERENCES public.home_people(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpage_image_id_a60e2e91_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpage
    ADD CONSTRAINT blog_blogpage_image_id_a60e2e91_fk_wagtailimages_image_id FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpage_page_ptr_id_1d78e2b7_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpage
    ADD CONSTRAINT blog_blogpage_page_ptr_id_1d78e2b7_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpagetag_content_object_id_0dc644d2_fk_blog_blog; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpagetag
    ADD CONSTRAINT blog_blogpagetag_content_object_id_0dc644d2_fk_blog_blog FOREIGN KEY (content_object_id) REFERENCES public.blog_blogpage(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpagetag_tag_id_81dc0e5f_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogpagetag
    ADD CONSTRAINT blog_blogpagetag_tag_id_81dc0e5f_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogtagindexpag_page_ptr_id_3fc546db_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.blog_blogtagindexpage
    ADD CONSTRAINT blog_blogtagindexpag_page_ptr_id_3fc546db_fk_wagtailco FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepage_featured_section_1_i_e534fc28_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_featured_section_1_i_e534fc28_fk_wagtailco FOREIGN KEY (featured_section_1_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepage_featured_section_2_i_d578d895_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_featured_section_2_i_d578d895_fk_wagtailco FOREIGN KEY (featured_section_2_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepage_page_ptr_id_e5b77cf7_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_page_ptr_id_e5b77cf7_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepage_promo_image_id_afb37fd6_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_promo_image_id_afb37fd6_fk_wagtailimages_image_id FOREIGN KEY (promo_image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepage_resume_id_12b2dcc6_fk_wagtaildocs_document_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepage
    ADD CONSTRAINT home_homepage_resume_id_12b2dcc6_fk_wagtaildocs_document_id FOREIGN KEY (resume_id) REFERENCES public.wagtaildocs_document(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepageimagega_image_id_d9c1ad51_fk_wagtailim; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepageimagegallery
    ADD CONSTRAINT home_homepageimagega_image_id_d9c1ad51_fk_wagtailim FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepageimagega_page_id_fc7957cc_fk_home_home; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_homepageimagegallery
    ADD CONSTRAINT home_homepageimagega_page_id_fc7957cc_fk_home_home FOREIGN KEY (page_id) REFERENCES public.home_homepage(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_people_image_id_7999b56e_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_people
    ADD CONSTRAINT home_people_image_id_7999b56e_fk_wagtailimages_image_id FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_skills_page_id_f45d6f6c_fk_home_homepage_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_skills
    ADD CONSTRAINT home_skills_page_id_f45d6f6c_fk_home_homepage_page_ptr_id FOREIGN KEY (page_id) REFERENCES public.home_homepage(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_standardpage_image_id_bd2b3ffc_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_standardpage
    ADD CONSTRAINT home_standardpage_image_id_bd2b3ffc_fk_wagtailimages_image_id FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_standardpage_page_ptr_id_9284d8b1_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.home_standardpage
    ADD CONSTRAINT home_standardpage_page_ptr_id_9284d8b1_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_projectinde_page_ptr_id_dd5e70ca_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectindexpage
    ADD CONSTRAINT projects_projectinde_page_ptr_id_dd5e70ca_fk_wagtailco FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_projectpage_image_id_809a87d8_fk_wagtailim; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpagegalleryimage
    ADD CONSTRAINT projects_projectpage_image_id_809a87d8_fk_wagtailim FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_projectpage_image_id_d50212f0_fk_wagtailim; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpage
    ADD CONSTRAINT projects_projectpage_image_id_d50212f0_fk_wagtailim FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_projectpage_page_id_d646f194_fk_projects_; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpagegalleryimage
    ADD CONSTRAINT projects_projectpage_page_id_d646f194_fk_projects_ FOREIGN KEY (page_id) REFERENCES public.projects_projectpage(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_projectpage_page_ptr_id_2eccd927_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.projects_projectpage
    ADD CONSTRAINT projects_projectpage_page_ptr_id_2eccd927_fk_wagtailco FOREIGN KEY (page_ptr_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem_content_type_id_9957a03c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_9957a03c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_collecti_collection_id_761908ec_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction
    ADD CONSTRAINT wagtailcore_collecti_collection_id_761908ec_fk_wagtailco FOREIGN KEY (collection_id) REFERENCES public.wagtailcore_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_collecti_collectionviewrestri_47320efd_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction_groups
    ADD CONSTRAINT wagtailcore_collecti_collectionviewrestri_47320efd_fk_wagtailco FOREIGN KEY (collectionviewrestriction_id) REFERENCES public.wagtailcore_collectionviewrestriction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_collecti_group_id_1823f2a3_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_collectionviewrestriction_groups
    ADD CONSTRAINT wagtailcore_collecti_group_id_1823f2a3_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_groupcol_collection_id_5423575a_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission
    ADD CONSTRAINT wagtailcore_groupcol_collection_id_5423575a_fk_wagtailco FOREIGN KEY (collection_id) REFERENCES public.wagtailcore_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_groupcol_group_id_05d61460_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission
    ADD CONSTRAINT wagtailcore_groupcol_group_id_05d61460_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_groupcol_permission_id_1b626275_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_groupcollectionpermission
    ADD CONSTRAINT wagtailcore_groupcol_permission_id_1b626275_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_grouppag_group_id_fc07e671_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppag_group_id_fc07e671_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_grouppag_page_id_710b114a_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppag_page_id_710b114a_fk_wagtailco FOREIGN KEY (page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_page_content_type_id_c28424df_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_content_type_id_c28424df_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_page_live_revision_id_930bd822_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_live_revision_id_930bd822_fk_wagtailco FOREIGN KEY (live_revision_id) REFERENCES public.wagtailcore_pagerevision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_page_owner_id_fbf7c332_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_owner_id_fbf7c332_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pagerevi_page_id_d421cc1d_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_pagerevi_page_id_d421cc1d_fk_wagtailco FOREIGN KEY (page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pagerevision_user_id_2409d2f4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_pagerevision_user_id_2409d2f4_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pageview_group_id_6460f223_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction_groups
    ADD CONSTRAINT wagtailcore_pageview_group_id_6460f223_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pageview_page_id_15a8bea6_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction
    ADD CONSTRAINT wagtailcore_pageview_page_id_15a8bea6_fk_wagtailco FOREIGN KEY (page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pageview_pageviewrestriction__f147a99a_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_pageviewrestriction_groups
    ADD CONSTRAINT wagtailcore_pageview_pageviewrestriction__f147a99a_fk_wagtailco FOREIGN KEY (pageviewrestriction_id) REFERENCES public.wagtailcore_pageviewrestriction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_site_root_page_id_e02fb95c_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailcore_site
    ADD CONSTRAINT wagtailcore_site_root_page_id_e02fb95c_fk_wagtailcore_page_id FOREIGN KEY (root_page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtaildocs_document_collection_id_23881625_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtaildocs_document
    ADD CONSTRAINT wagtaildocs_document_collection_id_23881625_fk_wagtailco FOREIGN KEY (collection_id) REFERENCES public.wagtailcore_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtaildocs_document_uploaded_by_user_id_17258b41_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtaildocs_document
    ADD CONSTRAINT wagtaildocs_document_uploaded_by_user_id_17258b41_fk_auth_user FOREIGN KEY (uploaded_by_user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailforms_formsub_page_id_e48e93e7_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailforms_formsubmission
    ADD CONSTRAINT wagtailforms_formsub_page_id_e48e93e7_fk_wagtailco FOREIGN KEY (page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailimages_image_collection_id_c2f8af7e_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_image
    ADD CONSTRAINT wagtailimages_image_collection_id_c2f8af7e_fk_wagtailco FOREIGN KEY (collection_id) REFERENCES public.wagtailcore_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailimages_image_uploaded_by_user_id_5d73dc75_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_image
    ADD CONSTRAINT wagtailimages_image_uploaded_by_user_id_5d73dc75_fk_auth_user FOREIGN KEY (uploaded_by_user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailimages_rendit_image_id_3e1fd774_fk_wagtailim; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailimages_rendition
    ADD CONSTRAINT wagtailimages_rendit_image_id_3e1fd774_fk_wagtailim FOREIGN KEY (image_id) REFERENCES public.wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailredirects_red_redirect_page_id_b5728a8f_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_red_redirect_page_id_b5728a8f_fk_wagtailco FOREIGN KEY (redirect_page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailredirects_red_site_id_780a0e1e_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_red_site_id_780a0e1e_fk_wagtailco FOREIGN KEY (site_id) REFERENCES public.wagtailcore_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsearch_editor_page_id_28cbc274_fk_wagtailco; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsearch_editor_page_id_28cbc274_fk_wagtailco FOREIGN KEY (page_id) REFERENCES public.wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsearch_editor_query_id_c6eee4a0_fk_wagtailse; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsearch_editor_query_id_c6eee4a0_fk_wagtailse FOREIGN KEY (query_id) REFERENCES public.wagtailsearch_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsearch_queryd_query_id_2185994b_fk_wagtailse; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsearch_queryd_query_id_2185994b_fk_wagtailse FOREIGN KEY (query_id) REFERENCES public.wagtailsearch_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailusers_userprofile_user_id_59c92331_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: andrew
--

ALTER TABLE ONLY public.wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_userprofile_user_id_59c92331_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

